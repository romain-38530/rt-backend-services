#!/usr/bin/env node

/**
 * Script de Test - Synchronisation Affret.IA → Dashdoc
 *
 * Teste le système complet de mise à jour automatique des transports Dashdoc
 * lors de l'affectation d'une commande par Affret.IA
 */

const mongoose = require('mongoose');
const affretIADashdocSyncService = require('../services/affretia-dashdoc-sync.service');
const DashdocUpdateConnector = require('../connectors/dashdoc-update.connector');

// Couleurs
const colors = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  cyan: '\x1b[36m',
  red: '\x1b[31m',
  bold: '\x1b[1m'
};

function printSuccess(text) {
  console.log(`${colors.green}✓${colors.reset} ${text}`);
}

function printError(text) {
  console.log(`${colors.red}✗${colors.reset} ${text}`);
}

function printInfo(text) {
  console.log(`${colors.cyan}ℹ${colors.reset} ${text}`);
}

function printHeader(text) {
  console.log('\n' + colors.bold + colors.cyan + '═'.repeat(70) + colors.reset);
  console.log(colors.bold + colors.cyan + text + colors.reset);
  console.log(colors.bold + colors.cyan + '═'.repeat(70) + colors.reset + '\n');
}

async function testDashdocUpdateConnector() {
  printHeader('TEST 1: Dashdoc Update Connector');

  const apiToken = process.env.DASHDOC_API_TOKEN;

  if (!apiToken) {
    printError('DASHDOC_API_TOKEN non défini dans .env');
    return false;
  }

  try {
    const connector = new DashdocUpdateConnector(apiToken);

    // Test 1.1: Récupérer l'adresse d'un transporteur
    printInfo('Test 1.1: Récupération adresse transporteur...');

    const companyPk = process.env.TEST_COMPANY_PK || '123'; // À remplacer

    const addressResult = await connector.getCarrierAddress(companyPk);

    if (addressResult.success) {
      printSuccess(`Adresse récupérée: PK ${addressResult.addressPk}`);
    } else {
      printError(`Échec: ${addressResult.error}`);
    }

    // Test 1.2: Rechercher un véhicule
    printInfo('Test 1.2: Recherche véhicule par plaque...');

    const licensePlate = process.env.TEST_VEHICLE_PLATE || 'AA-123-BB';

    const vehicleResult = await connector.findVehicleByPlate(licensePlate);

    if (vehicleResult.success) {
      printSuccess(`Véhicule trouvé: ${vehicleResult.vehicle.license_plate}`);
    } else {
      printError(`Véhicule non trouvé: ${vehicleResult.error}`);
    }

    // Test 1.3: Rechercher un chauffeur
    printInfo('Test 1.3: Recherche chauffeur par email...');

    const driverEmail = process.env.TEST_DRIVER_EMAIL || 'driver@example.com';

    const driverResult = await connector.findDriverByEmail(driverEmail);

    if (driverResult.success) {
      printSuccess(`Chauffeur trouvé: ${driverResult.driver.user.first_name} ${driverResult.driver.user.last_name}`);
    } else {
      printError(`Chauffeur non trouvé: ${driverResult.error}`);
    }

    printSuccess('Connecteur Dashdoc Update validé');
    return true;

  } catch (error) {
    printError(`Erreur test connecteur: ${error.message}`);
    return false;
  }
}

async function testSyncService() {
  printHeader('TEST 2: Service de Synchronisation');

  try {
    // Connexion MongoDB
    printInfo('Connexion à MongoDB...');

    const mongoUri = process.env.MONGODB_URI;

    if (!mongoUri) {
      printError('MONGODB_URI non défini dans .env');
      return false;
    }

    await mongoose.connect(mongoUri);
    printSuccess('Connecté à MongoDB');

    // Initialiser le service
    printInfo('Initialisation du service...');

    await affretIADashdocSyncService.initialize();

    printSuccess('Service initialisé');

    const connectorsCount = affretIADashdocSyncService.connectors.size;
    console.log(`  Connecteurs chargés: ${connectorsCount}`);

    if (connectorsCount === 0) {
      printError('Aucun connecteur Dashdoc chargé (aucune connexion active)');
      return false;
    }

    printSuccess('Service de synchronisation validé');
    return true;

  } catch (error) {
    printError(`Erreur test service: ${error.message}`);
    return false;
  }
}

async function testManualSync() {
  printHeader('TEST 3: Synchronisation Manuelle');

  const orderId = process.env.TEST_ORDER_ID;

  if (!orderId) {
    printError('TEST_ORDER_ID non défini dans .env');
    printInfo('Ajoutez dans .env: TEST_ORDER_ID=<mongo_order_id>');
    return false;
  }

  try {
    printInfo(`Synchronisation de la commande ${orderId}...`);

    const result = await affretIADashdocSyncService.manualSync(orderId, {
      price: 450.00,
      sellingPrice: 600.00
    });

    if (result.success) {
      printSuccess('Synchronisation manuelle réussie');
      console.log(`  Transport UID: ${result.transportUid}`);
      console.log(`  Retries: ${result.retriesUsed}`);
      return true;
    } else {
      printError(`Échec synchronisation: ${result.error}`);
      return false;
    }

  } catch (error) {
    printError(`Erreur test sync manuelle: ${error.message}`);
    return false;
  }
}

async function testEventHandling() {
  printHeader('TEST 4: Gestion des Événements');

  const orderId = process.env.TEST_ORDER_ID;
  const carrierId = process.env.TEST_CARRIER_ID;

  if (!orderId || !carrierId) {
    printError('TEST_ORDER_ID ou TEST_CARRIER_ID non défini dans .env');
    return false;
  }

  try {
    printInfo('Simulation événement carrier.assigned...');

    const result = await affretIADashdocSyncService.handleCarrierAssigned({
      orderId,
      carrierId,
      price: 450.00,
      sessionId: 'test-session-123'
    });

    if (result.success) {
      printSuccess('Événement traité avec succès');
      return true;
    } else {
      printError(`Échec traitement événement: ${result.error}`);
      return false;
    }

  } catch (error) {
    printError(`Erreur test événement: ${error.message}`);
    return false;
  }
}

async function main() {
  console.log('\n' + colors.bold + colors.cyan + '╔══════════════════════════════════════════════════════════════╗' + colors.reset);
  console.log(colors.bold + colors.cyan + '║  Test Synchronisation Affret.IA → Dashdoc                   ║' + colors.reset);
  console.log(colors.bold + colors.cyan + '╚══════════════════════════════════════════════════════════════╝' + colors.reset);

  const results = {
    connector: false,
    service: false,
    manualSync: false,
    eventHandling: false
  };

  // Test 1: Connecteur Dashdoc Update
  results.connector = await testDashdocUpdateConnector();

  // Test 2: Service de synchronisation
  results.service = await testSyncService();

  // Test 3: Synchronisation manuelle (optionnel)
  if (process.env.TEST_ORDER_ID) {
    results.manualSync = await testManualSync();
  } else {
    printInfo('Test 3 ignoré (TEST_ORDER_ID non défini)');
  }

  // Test 4: Gestion des événements (optionnel)
  if (process.env.TEST_ORDER_ID && process.env.TEST_CARRIER_ID) {
    results.eventHandling = await testEventHandling();
  } else {
    printInfo('Test 4 ignoré (TEST_ORDER_ID ou TEST_CARRIER_ID non défini)');
  }

  // Rapport final
  printHeader('RÉSULTATS');

  const total = Object.keys(results).length;
  const passed = Object.values(results).filter(r => r === true).length;
  const skipped = Object.values(results).filter(r => r === null).length;
  const failed = total - passed - skipped;

  console.log(`Tests exécutés: ${total}`);
  console.log(`${colors.green}Réussis: ${passed}${colors.reset}`);
  console.log(`${colors.yellow}Ignorés: ${skipped}${colors.reset}`);
  console.log(`${colors.red}Échoués: ${failed}${colors.reset}`);
  console.log('');

  if (failed === 0 && passed > 0) {
    console.log(colors.green + colors.bold + '✅ Tous les tests sont passés!' + colors.reset);
    console.log('');
    console.log('Prochaines étapes:');
    console.log('  1. Configurer les variables de test dans .env');
    console.log('  2. Intégrer dans index.js (voir INTEGRATION-AFFRETIA-SYNC.md)');
    console.log('  3. Tester en production avec une vraie commande');
    console.log('');
  } else {
    console.log(colors.red + colors.bold + '❌ Certains tests ont échoué' + colors.reset);
    console.log('');
    console.log('Vérifiez:');
    console.log('  1. Les credentials Dashdoc dans .env');
    console.log('  2. La connexion MongoDB');
    console.log('  3. Les IDs de test (order, carrier, company)');
    console.log('');
  }

  // Déconnexion MongoDB
  if (mongoose.connection.readyState === 1) {
    await mongoose.disconnect();
    printInfo('Déconnecté de MongoDB');
  }

  process.exit(failed === 0 ? 0 : 1);
}

// Gestion des erreurs non catchées
process.on('unhandledRejection', (error) => {
  console.error('\n' + colors.red + 'Unhandled Rejection:' + colors.reset, error);
  process.exit(1);
});

main().catch(error => {
  console.error('\n' + colors.red + 'Erreur fatale:' + colors.reset, error);
  process.exit(1);
});
