const { MongoClient } = require('mongodb');

async function checkOrder() {
  const client = new MongoClient('mongodb+srv://rt_admin:RtAdmin2024@stagingrt.v2jnoh2.mongodb.net/symphonia?retryWrites=true&w=majority');

  try {
    await client.connect();
    const db = client.db('symphonia');

    console.log('🔍 Recherche de la commande 32230532...\n');

    // Chercher par différents critères
    const order = await db.collection('orders').findOne({
      $or: [
        { 'externalId': '019-c0919-e755-7083-b098-00b4f32f028c' },
        { 'orderNumber': '32230532' },
        { 'metadata.dashdoc_sequential_id': '32230532' }
      ]
    });

    if (order) {
      console.log('✅ Commande TROUVÉE dans MongoDB:\n');
      console.log('Order Number:', order.orderNumber);
      console.log('External ID:', order.externalId);
      console.log('Status:', order.status);
      console.log('Created At:', order.createdAt);
      console.log('Tags:', JSON.stringify(order.tags, null, 2));
      console.log('External Source:', order.externalSource);
    } else {
      console.log('❌ Commande NON TROUVÉE dans MongoDB\n');

      // Statistiques
      const dashdocCount = await db.collection('orders').countDocuments({ externalSource: 'dashdoc' });
      console.log('Total commandes Dashdoc:', dashdocCount);

      // Voir la dernière commande Dashdoc
      const lastOrder = await db.collection('orders').findOne(
        { externalSource: 'dashdoc' },
        { sort: { createdAt: -1 } }
      );
      if (lastOrder) {
        console.log('\nDernière commande Dashdoc synchronisée:');
        console.log('  - Order Number:', lastOrder.orderNumber);
        console.log('  - Created At:', lastOrder.createdAt);
        console.log('  - Tags:', JSON.stringify(lastOrder.tags, null, 2));
      }

      // Compter commandes avec tag symphonia
      const symphoCount = await db.collection('orders').countDocuments({
        externalSource: 'dashdoc',
        'tags.name': /symphonia/i
      });
      console.log('\nCommandes avec tag Symphonia:', symphoCount);
    }

  } finally {
    await client.close();
  }
}

checkOrder().catch(console.error);
