/**
 * Check carriers count in MongoDB
 */

const { MongoClient } = require('mongodb');

const MONGODB_URI = 'mongodb+srv://rt_admin:SXmnNXTiAN5KtAaPLdhGHqLiXB5KX7Vd@stagingrt.v2jnoh2.mongodb.net/rt-tms-sync';

async function checkCarriersCount() {
  const client = new MongoClient(MONGODB_URI);

  try {
    console.log('🔄 Connexion à MongoDB...');
    await client.connect();
    console.log('✅ Connecté à MongoDB\n');

    const db = client.db('rt-tms-sync');
    const carriersCollection = db.collection('carriers');

    // Compter le total
    const totalCount = await carriersCollection.countDocuments();
    console.log(`📊 Total carriers dans MongoDB: ${totalCount}`);

    // Compter par source
    const dashdocCount = await carriersCollection.countDocuments({
      externalSource: 'dashdoc'
    });
    console.log(`   - Dashdoc: ${dashdocCount}`);

    // Voir les derniers carriers ajoutés
    console.log('\n📅 Derniers carriers ajoutés:');
    const recentCarriers = await carriersCollection
      .find({ externalSource: 'dashdoc' })
      .sort({ createdAt: -1 })
      .limit(5)
      .toArray();

    recentCarriers.forEach((c, i) => {
      console.log(`   ${i + 1}. ${c.companyName} (${c.externalId}) - Créé: ${c.createdAt}`);
    });

    // Vérifier la dernière mise à jour
    console.log('\n🕒 Carriers mis à jour récemment:');
    const updatedCarriers = await carriersCollection
      .find({ externalSource: 'dashdoc' })
      .sort({ updatedAt: -1 })
      .limit(3)
      .toArray();

    updatedCarriers.forEach((c, i) => {
      console.log(`   ${i + 1}. ${c.companyName} - MAJ: ${c.updatedAt}`);
    });

  } catch (error) {
    console.error('❌ Erreur:', error.message);
    process.exit(1);
  } finally {
    await client.close();
  }
}

checkCarriersCount();
