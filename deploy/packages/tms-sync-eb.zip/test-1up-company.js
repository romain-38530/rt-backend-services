/**
 * Test direct de l'API Dashdoc pour voir les données de "1 UP"
 */

const axios = require('axios');

const DASHDOC_TOKEN = 'bc6a88fb5ad9eab9b8ba03e885e1f2ea5a62a04e'; // Token from env
const DASHDOC_API = 'https://www.dashdoc.eu/api/v4';

async function testOneUp() {
  const client = axios.create({
    baseURL: DASHDOC_API,
    headers: {
      'Authorization': `Token ${DASHDOC_TOKEN}`,
      'Content-Type': 'application/json'
    }
  });

  console.log('🔍 Testing "1 UP" company in Dashdoc API\n');
  console.log('==========================================\n');

  try {
    // Test 1: Recherche par nom
    console.log('1️⃣  Searching for "1 UP" by name...');
    const search = await client.get('/companies/?name=1 UP&limit=5');
    console.log(`   Found ${search.data.count} companies`);

    if (search.data.results.length > 0) {
      const company = search.data.results[0];
      console.log('\n   Company details:');
      console.log(`   - Name: ${company.name}`);
      console.log(`   - PK: ${company.pk}`);
      console.log(`   - is_carrier: ${company.is_carrier}`);
      console.log(`   - is_shipper: ${company.is_shipper}`);
      console.log(`   - account_type: ${company.account_type}`);
      console.log(`   - is_verified: ${company.is_verified}`);
    }

    // Test 2: GET avec is_carrier=true seulement
    console.log('\n2️⃣  GET /companies/?is_carrier=true&limit=10');
    const carriers1 = await client.get('/companies/?is_carrier=true&limit=10');
    console.log(`   Total carriers: ${carriers1.data.count}`);

    const oneUp1 = carriers1.data.results.find(c => c.name === '1 UP');
    console.log(`   "1 UP" found: ${oneUp1 ? 'YES ❌' : 'NO ✅'}`);

    // Test 3: GET avec is_carrier=true ET is_shipper=false
    console.log('\n3️⃣  GET /companies/?is_carrier=true&is_shipper=false&limit=10');
    const carriers2 = await client.get('/companies/?is_carrier=true&is_shipper=false&limit=10');
    console.log(`   Total carriers: ${carriers2.data.count}`);

    const oneUp2 = carriers2.data.results.find(c => c.name === '1 UP');
    console.log(`   "1 UP" found: ${oneUp2 ? 'YES ❌' : 'NO ✅'}`);

    // Test 4: Vérifier si le filtre is_shipper=false réduit le nombre
    console.log('\n4️⃣  Comparison:');
    console.log(`   With is_carrier=true only: ${carriers1.data.count} companies`);
    console.log(`   With is_carrier=true & is_shipper=false: ${carriers2.data.count} companies`);

    if (carriers1.data.count === carriers2.data.count) {
      console.log('   ⚠️  Filter has NO effect - is_shipper parameter may not be supported!');
    } else {
      console.log(`   ✅ Filter works - excluded ${carriers1.data.count - carriers2.data.count} shippers`);
    }

    console.log('\n==========================================\n');

  } catch (error) {
    console.error('❌ Error:', error.message);
    if (error.response) {
      console.error('   Status:', error.response.status);
      console.error('   Data:', error.response.data);
    }
  }
}

testOneUp();
