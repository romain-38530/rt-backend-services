/**
 * Test: Vérifier que le filtre is_shipper=false fonctionne
 * Vérifie si "1 UP" est retourné par l'API Dashdoc
 */

const { MongoClient } = require('mongodb');
const DashdocConnector = require('./connectors/dashdoc.connector');

async function testFilter() {
  const client = new MongoClient('mongodb+srv://rt_admin:RtAdmin2024@stagingrt.v2jnoh2.mongodb.net/symphonia?retryWrites=true&w=majority');

  try {
    await client.connect();
    const db = client.db('symphonia');

    // Récupérer la connexion Dashdoc
    const connection = await db.collection('tmsConnections').findOne({
      tmsType: 'dashdoc',
      isActive: true
    });

    if (!connection) {
      console.error('❌ No Dashdoc connection found');
      return;
    }

    console.log('✅ Found Dashdoc connection:', connection.organizationName);

    // Créer le connector
    const dashdoc = new DashdocConnector(connection.credentials.apiToken, {
      baseUrl: connection.credentials.apiUrl
    });

    console.log('\n🔍 Testing getCarriers() with filters...');
    const result = await dashdoc.getCarriers({ limit: 100 });

    console.log(`\n📊 Results:`);
    console.log(`  Total carriers returned: ${result.count}`);
    console.log(`  Carriers mapped: ${result.results.length}`);

    // Chercher "1 UP"
    const oneUp = result.results.find(c => c.companyName === '1 UP');

    if (oneUp) {
      console.log('\n❌ "1 UP" FOUND in results (should be filtered!)');
      console.log('  Company:', oneUp.companyName);
      console.log('  Account Type:', oneUp.accountType);
      console.log('  External ID:', oneUp.externalId);
      console.log('  SIRET:', oneUp.siret);
    } else {
      console.log('\n✅ "1 UP" NOT found in results (correctly filtered!)');
    }

    // Afficher les 5 premiers carriers
    console.log('\n📋 First 5 carriers:');
    result.results.slice(0, 5).forEach((c, i) => {
      console.log(`  ${i + 1}. ${c.companyName} (${c.accountType})`);
    });

    // Compter par accountType
    const accountTypes = {};
    result.results.forEach(c => {
      accountTypes[c.accountType] = (accountTypes[c.accountType] || 0) + 1;
    });

    console.log('\n📊 Carriers by accountType:');
    Object.entries(accountTypes).forEach(([type, count]) => {
      console.log(`  ${type}: ${count}`);
    });

  } finally {
    await client.close();
  }
}

testFilter().catch(console.error);
