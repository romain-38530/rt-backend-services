# Test de l'API en production AWS
$baseUrl = "https://rt-tms-sync-api-v2.eba-gpxm3qif.eu-central-1.elasticbeanstalk.com"

Write-Host "=== TEST API TMS SYNC PRODUCTION ===" -ForegroundColor Cyan
Write-Host ""

# Test 1: GET /api/v1/tms/connections
Write-Host "Test 1: Liste des connexions TMS" -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$baseUrl/api/v1/tms/connections" -Method Get -TimeoutSec 15
    Write-Host "[OK] Status: 200" -ForegroundColor Green
    Write-Host "Connexions trouvees: $($response.connections.Count)" -ForegroundColor Green
    if ($response.connections.Count -gt 0) {
        Write-Host "Premiere connexion: $($response.connections[0].organizationName)" -ForegroundColor Cyan
    }
} catch {
    Write-Host "[ERREUR] $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""

# Test 2: GET /api/v1/tms/orders
Write-Host "Test 2: Liste des commandes (limit=5)" -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$baseUrl/api/v1/tms/orders?limit=5" -Method Get -TimeoutSec 15
    Write-Host "[OK] Status: 200" -ForegroundColor Green
    Write-Host "Commandes trouvees: $($response.orders.Count)" -ForegroundColor Green
    Write-Host "Total dans la BDD: $($response.total)" -ForegroundColor Cyan
} catch {
    Write-Host "[ERREUR] $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""

# Test 3: GET /api/v1/tms/orders?toPlan=true
Write-Host "Test 3: Commandes 'A planifier' (toPlan=true)" -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "$baseUrl/api/v1/tms/orders?toPlan=true&limit=5" -Method Get -TimeoutSec 15
    Write-Host "[OK] Status: 200" -ForegroundColor Green
    Write-Host "Commandes 'A planifier': $($response.orders.Count)" -ForegroundColor Green
    Write-Host "Total dans la BDD: $($response.total)" -ForegroundColor Cyan
    if ($response.orders.Count -gt 0) {
        Write-Host "Statuts: $($response.orders.status -join ', ')" -ForegroundColor Cyan
    }
} catch {
    Write-Host "[ERREUR] $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""
Write-Host "=== FIN DES TESTS ===" -ForegroundColor Cyan
