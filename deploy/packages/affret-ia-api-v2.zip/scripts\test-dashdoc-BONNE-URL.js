/**
 * Test avec la BONNE URL : api.dashdoc.EU (pas .com)
 * Découverte du support Dashdoc : https://api.dashdoc.eu ✅
 */

const axios = require('axios');

const API_KEY = '8321c7a8f7fe8f75192fa15a6c883a11758e0084';
const BASE_URL = 'https://api.dashdoc.eu/api/v4';  // ✅ .EU et non .com !

console.log('\n' + '='.repeat(80));
console.log('  TEST AVEC LA BONNE URL - api.dashdoc.EU');
console.log('='.repeat(80));
console.log();
console.log(`Clé API: ${API_KEY.substring(0, 20)}...`);
console.log(`Base URL: ${BASE_URL}  ✅ .EU`);
console.log(`Format: Authorization: Token <key>`);
console.log();

async function testDashdocAPI() {
  const tests = [
    // Test 1: Simple
    {
      name: '1. GET /transports/?page_size=1',
      config: {
        method: 'GET',
        url: `${BASE_URL}/transports/`,
        headers: {
          'Authorization': `Token ${API_KEY}`,
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        params: {
          page_size: 1
        },
        timeout: 15000
      }
    },

    // Test 2: Avec filtres (notre cas d'usage)
    {
      name: '2. GET /transports/ (status=done, is_subcontracted=true)',
      config: {
        method: 'GET',
        url: `${BASE_URL}/transports/`,
        headers: {
          'Authorization': `Token ${API_KEY}`,
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        params: {
          status: 'done',
          is_subcontracted: true,
          page_size: 10
        },
        timeout: 15000
      }
    },

    // Test 3: Avec période (6 derniers mois)
    {
      name: '3. GET /transports/ (6 derniers mois)',
      config: {
        method: 'GET',
        url: `${BASE_URL}/transports/`,
        headers: {
          'Authorization': `Token ${API_KEY}`,
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        params: {
          status: 'done',
          is_subcontracted: true,
          created_after: new Date(Date.now() - 180 * 24 * 60 * 60 * 1000).toISOString(),
          page_size: 100
        },
        timeout: 15000
      }
    }
  ];

  let successCount = 0;

  for (const test of tests) {
    console.log(`\n${'─'.repeat(80)}`);
    console.log(`TEST: ${test.name}`);
    console.log('─'.repeat(80));

    try {
      console.log(`URL: ${test.config.url}`);
      if (test.config.params) {
        console.log(`Params:`, JSON.stringify(test.config.params, null, 2));
      }
      console.log();

      const response = await axios(test.config);

      console.log(`✅ SUCCÈS - HTTP ${response.status}`);
      console.log();

      // Afficher les informations utiles
      if (response.data.count !== undefined) {
        console.log(`📊 Résultats: ${response.data.count} transports trouvés`);
      }

      if (response.data.results && Array.isArray(response.data.results)) {
        console.log(`📦 Transports retournés: ${response.data.results.length}`);

        if (response.data.results.length > 0) {
          const transport = response.data.results[0];
          console.log();
          console.log('📋 Premier transport:');
          console.log(`   UID: ${transport.uid}`);
          console.log(`   Status: ${transport.status}`);

          // Vérifier prix sous-traitant
          if (transport.charter?.price) {
            console.log(`   💰 Prix sous-traitant (charter.price): ${transport.charter.price}€`);
          } else if (transport.subcontracting?.price) {
            console.log(`   💰 Prix sous-traitant (subcontracting.price): ${transport.subcontracting.price}€`);
          } else if (transport.pricing?.invoicing_amount) {
            console.log(`   ⚠️ Prix client (pricing.invoicing_amount): ${transport.pricing.invoicing_amount}€`);
          }

          // Vérifier transporteur
          if (transport.charter?.carrier?.name) {
            console.log(`   🚛 Transporteur: ${transport.charter.carrier.name}`);
          } else if (transport.subcontracting?.carrier?.name) {
            console.log(`   🚛 Transporteur: ${transport.subcontracting.carrier.name}`);
          }

          // Vérifier route
          if (transport.origin?.address?.city && transport.destination?.address?.city) {
            console.log(`   📍 Route: ${transport.origin.address.city} → ${transport.destination.address.city}`);
          }
        }
      }

      successCount++;

    } catch (error) {
      console.log(`❌ ÉCHEC`);
      console.log();

      if (error.response) {
        console.log(`HTTP Status: ${error.response.status} ${error.response.statusText}`);
        console.log(`Response:`, JSON.stringify(error.response.data, null, 2));
      } else if (error.request) {
        console.log(`Pas de réponse du serveur`);
        console.log(`Error:`, error.message);
      } else {
        console.log(`Error:`, error.message);
      }
    }
  }

  console.log();
  console.log('='.repeat(80));
  console.log('  RÉSULTAT FINAL');
  console.log('='.repeat(80));
  console.log();

  if (successCount > 0) {
    console.log(`✅ ${successCount}/${tests.length} test(s) réussi(s)`);
    console.log();
    console.log('🎉 LA CLÉ API FONCTIONNE AVEC LA BONNE URL !');
    console.log();
    console.log('📝 PROCHAINES ÉTAPES:');
    console.log();
    console.log('1. Mettre à jour pricing.service.js avec la bonne URL');
    console.log('2. Mettre à jour la variable AWS EB DASHDOC_API_URL');
    console.log('3. Tester l\'import Dashdoc en production');
    console.log();
    console.log('⚠️ IMPORTANT: URL correcte = https://api.dashdoc.eu (pas .com !)');
    console.log();
  } else {
    console.log(`❌ 0/${tests.length} test(s) réussi(s)`);
    console.log();
    console.log('⚠️ Échec même avec la bonne URL (.eu)');
    console.log();
  }
}

// Exécution
testDashdocAPI().catch(error => {
  console.error('Erreur fatale:', error);
  process.exit(1);
});
