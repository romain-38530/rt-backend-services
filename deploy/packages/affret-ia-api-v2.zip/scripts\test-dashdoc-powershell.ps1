# Test avec Invoke-RestMethod natif PowerShell
# Format EXACT fourni par le support Dashdoc

$API_KEY = "8321c7a8f7fe8f75192fa15a6c883a11758e0084"
$BASE_URL = "https://api.dashdoc.com/api/v4"

Write-Host "================================================================================" -ForegroundColor Cyan
Write-Host "  TEST DASHDOC API - Invoke-RestMethod (PowerShell natif)" -ForegroundColor Cyan
Write-Host "================================================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Clé API: $($API_KEY.Substring(0,20))..."
Write-Host "Format: Authorization: Token <key>"
Write-Host "Base URL: $BASE_URL"
Write-Host ""

# Obtenir l'IP publique
Write-Host "================================================================================" -ForegroundColor Cyan
Write-Host "VOTRE IP PUBLIQUE" -ForegroundColor Yellow
Write-Host "================================================================================" -ForegroundColor Cyan
Write-Host ""

try {
  $ipInfo = Invoke-RestMethod -Uri "https://api.ipify.org?format=json" -TimeoutSec 5
  Write-Host "IP publique: $($ipInfo.ip)" -ForegroundColor Green
  Write-Host ""
  Write-Host "⚠️ IMPORTANT: Fournissez cette IP au support Dashdoc !" -ForegroundColor Yellow
  Write-Host "   Ils doivent vérifier si la clé API a des restrictions IP." -ForegroundColor Yellow
  Write-Host ""
} catch {
  Write-Host "⚠️ Impossible de récupérer l'IP publique" -ForegroundColor Yellow
  Write-Host ""
}

Write-Host "================================================================================" -ForegroundColor Cyan
Write-Host ""

# Headers
$headers = @{
  "Authorization" = "Token $API_KEY"
  "Accept" = "application/json"
  "Content-Type" = "application/json"
}

# Test 1: Simple (page_size=1)
Write-Host "TEST 1: GET /transports/?page_size=1" -ForegroundColor Yellow
Write-Host "--------------------------------------------------------------------------------"
Write-Host ""
Write-Host "URL: ${BASE_URL}/transports/?page_size=1"
Write-Host "Headers:"
Write-Host "  Authorization: Token $($API_KEY.Substring(0,20))..."
Write-Host "  Accept: application/json"
Write-Host "  Content-Type: application/json"
Write-Host ""
Write-Host "Résultat:" -ForegroundColor Cyan
Write-Host ""

try {
  $response1 = Invoke-RestMethod -Uri "${BASE_URL}/transports/?page_size=1" `
    -Method Get `
    -Headers $headers `
    -TimeoutSec 15 `
    -ErrorAction Stop

  Write-Host "✅ SUCCÈS - HTTP 200" -ForegroundColor Green
  Write-Host ""
  if ($response1.count) {
    Write-Host "📊 Transports trouvés: $($response1.count)" -ForegroundColor Green
  }
  if ($response1.results -and $response1.results.Count -gt 0) {
    Write-Host "📦 Premier transport:"
    $firstTransport = $response1.results[0]
    if ($firstTransport.uid) { Write-Host "   UID: $($firstTransport.uid)" }
    if ($firstTransport.status) { Write-Host "   Status: $($firstTransport.status)" }
    if ($firstTransport.charter.price) {
      Write-Host "   💰 Prix sous-traitant (charter.price): $($firstTransport.charter.price)€" -ForegroundColor Green
    }
  }
  $test1Success = $true
} catch {
  Write-Host "❌ ÉCHEC" -ForegroundColor Red
  Write-Host ""
  Write-Host "HTTP Status: $($_.Exception.Response.StatusCode.Value__) $($_.Exception.Response.StatusDescription)" -ForegroundColor Red

  # Lire le corps de la réponse d'erreur
  try {
    $streamReader = [System.IO.StreamReader]::new($_.Exception.Response.GetResponseStream())
    $errorBody = $streamReader.ReadToEnd()
    Write-Host "Response: $errorBody" -ForegroundColor Red
  } catch {
    Write-Host "Response: $($_.Exception.Message)" -ForegroundColor Red
  }

  $test1Success = $false
}

Write-Host ""
Write-Host "================================================================================" -ForegroundColor Cyan
Write-Host ""

# Test 2: Avec filtres
Write-Host "TEST 2: GET /transports/?status=done&is_subcontracted=true&page_size=10" -ForegroundColor Yellow
Write-Host "--------------------------------------------------------------------------------"
Write-Host ""
Write-Host "URL: ${BASE_URL}/transports/?status=done&is_subcontracted=true&page_size=10"
Write-Host "Headers:"
Write-Host "  Authorization: Token $($API_KEY.Substring(0,20))..."
Write-Host "  Accept: application/json"
Write-Host "  Content-Type: application/json"
Write-Host ""
Write-Host "Résultat:" -ForegroundColor Cyan
Write-Host ""

try {
  $response2 = Invoke-RestMethod -Uri "${BASE_URL}/transports/?status=done&is_subcontracted=true&page_size=10" `
    -Method Get `
    -Headers $headers `
    -TimeoutSec 15 `
    -ErrorAction Stop

  Write-Host "✅ SUCCÈS - HTTP 200" -ForegroundColor Green
  Write-Host ""
  if ($response2.count) {
    Write-Host "📊 Transports sous-traités trouvés: $($response2.count)" -ForegroundColor Green
  }
  if ($response2.results) {
    Write-Host "📦 Transports retournés: $($response2.results.Count)" -ForegroundColor Green
  }
  $test2Success = $true
} catch {
  Write-Host "❌ ÉCHEC" -ForegroundColor Red
  Write-Host ""
  Write-Host "HTTP Status: $($_.Exception.Response.StatusCode.Value__) $($_.Exception.Response.StatusDescription)" -ForegroundColor Red

  # Lire le corps de la réponse d'erreur
  try {
    $streamReader = [System.IO.StreamReader]::new($_.Exception.Response.GetResponseStream())
    $errorBody = $streamReader.ReadToEnd()
    Write-Host "Response: $errorBody" -ForegroundColor Red
  } catch {
    Write-Host "Response: $($_.Exception.Message)" -ForegroundColor Red
  }

  $test2Success = $false
}

Write-Host ""
Write-Host "================================================================================" -ForegroundColor Cyan
Write-Host ""

# Résumé
Write-Host "RÉSUMÉ DES TESTS" -ForegroundColor Yellow
Write-Host "================================================================================" -ForegroundColor Cyan
Write-Host ""

if ($test1Success) {
  Write-Host "✅ Test 1: Succès (HTTP 200)" -ForegroundColor Green
} else {
  Write-Host "❌ Test 1: Échec (HTTP 401 ou autre erreur)" -ForegroundColor Red
}

if ($test2Success) {
  Write-Host "✅ Test 2: Succès (HTTP 200)" -ForegroundColor Green
} else {
  Write-Host "❌ Test 2: Échec (HTTP 401 ou autre erreur)" -ForegroundColor Red
}

Write-Host ""
Write-Host "================================================================================" -ForegroundColor Cyan
Write-Host ""

if ($test1Success -or $test2Success) {
  Write-Host "🎉 LA CLÉ API FONCTIONNE !" -ForegroundColor Green
  Write-Host ""
  Write-Host "Avec Invoke-RestMethod mais PAS avec Node.js axios ?" -ForegroundColor Yellow
  Write-Host "→ Vérifier les différences User-Agent ou headers entre les deux outils" -ForegroundColor Yellow
} else {
  Write-Host "⚠️ LA CLÉ API NE FONCTIONNE TOUJOURS PAS" -ForegroundColor Red
  Write-Host ""
  Write-Host "Même résultat qu'avec Node.js/axios (401)" -ForegroundColor Yellow
  Write-Host ""
  Write-Host "📝 INFORMATIONS POUR LE SUPPORT DASHDOC:" -ForegroundColor Yellow
  Write-Host ""
  Write-Host "Outil testé:" -ForegroundColor Cyan
  Write-Host "  - Node.js axios 1.6.2: ❌ 401"
  Write-Host "  - PowerShell Invoke-RestMethod: ❌ 401"
  Write-Host ""
  Write-Host "IP source (à vérifier pour whitelist):" -ForegroundColor Cyan
  Write-Host "  - IP développement: 77.205.88.170"
  Write-Host "  - IP production AWS: Dynamique eu-central-1"
  Write-Host ""
  Write-Host "Format utilisé:" -ForegroundColor Cyan
  Write-Host "  Authorization: Token 8321c7a8f7fe8f75192fa15a6c883a11758e0084"
  Write-Host ""
  Write-Host "Endpoints testés:" -ForegroundColor Cyan
  Write-Host "  1. https://api.dashdoc.com/api/v4/transports/?page_size=1"
  Write-Host '  2. https://api.dashdoc.com/api/v4/transports/?status=done&is_subcontracted=true&page_size=10'
  Write-Host ""
}

Write-Host ""
