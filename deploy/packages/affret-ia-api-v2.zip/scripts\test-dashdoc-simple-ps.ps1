# Test simple Dashdoc API avec PowerShell
$API_KEY = "8321c7a8f7fe8f75192fa15a6c883a11758e0084"
$BASE_URL = "https://api.dashdoc.com/api/v4"

Write-Host "================================================================================"
Write-Host "  TEST DASHDOC API - PowerShell"
Write-Host "================================================================================"
Write-Host ""

# IP publique
try {
  $ipInfo = Invoke-RestMethod -Uri "https://api.ipify.org?format=json" -TimeoutSec 5
  Write-Host "IP publique: $($ipInfo.ip)"
  Write-Host ""
} catch {
  Write-Host "Impossible de recuperer IP publique"
  Write-Host ""
}

Write-Host "================================================================================"
Write-Host ""

# Headers
$headers = @{
  "Authorization" = "Token $API_KEY"
  "Accept" = "application/json"
  "Content-Type" = "application/json"
}

# Test 1
Write-Host "TEST 1: GET /transports/?page_size=1"
Write-Host "--------------------------------------------------------------------------------"
Write-Host ""

try {
  $response1 = Invoke-RestMethod -Uri "${BASE_URL}/transports/?page_size=1" `
    -Method Get `
    -Headers $headers `
    -TimeoutSec 15 `
    -ErrorAction Stop

  Write-Host "SUCCES - HTTP 200"
  Write-Host ""
  if ($response1.count) {
    Write-Host "Transports trouves: $($response1.count)"
  }
  $test1Success = $true
} catch {
  Write-Host "ECHEC"
  Write-Host ""
  Write-Host "HTTP Status: $($_.Exception.Response.StatusCode.Value__)"

  try {
    $streamReader = [System.IO.StreamReader]::new($_.Exception.Response.GetResponseStream())
    $errorBody = $streamReader.ReadToEnd()
    Write-Host "Response: $errorBody"
  } catch {
    Write-Host "Response: $($_.Exception.Message)"
  }

  $test1Success = $false
}

Write-Host ""
Write-Host "================================================================================"
Write-Host ""

# Test 2
Write-Host "TEST 2: GET /transports/ (filtres status et is_subcontracted)"
Write-Host "--------------------------------------------------------------------------------"
Write-Host ""

try {
  $url2 = "${BASE_URL}/transports/?status=done"
  $url2 += "&is_subcontracted=true&page_size=10"

  $response2 = Invoke-RestMethod -Uri $url2 `
    -Method Get `
    -Headers $headers `
    -TimeoutSec 15 `
    -ErrorAction Stop

  Write-Host "SUCCES - HTTP 200"
  Write-Host ""
  if ($response2.count) {
    Write-Host "Transports sous-traites trouves: $($response2.count)"
  }
  $test2Success = $true
} catch {
  Write-Host "ECHEC"
  Write-Host ""
  Write-Host "HTTP Status: $($_.Exception.Response.StatusCode.Value__)"

  try {
    $streamReader = [System.IO.StreamReader]::new($_.Exception.Response.GetResponseStream())
    $errorBody = $streamReader.ReadToEnd()
    Write-Host "Response: $errorBody"
  } catch {
    Write-Host "Response: $($_.Exception.Message)"
  }

  $test2Success = $false
}

Write-Host ""
Write-Host "================================================================================"
Write-Host ""

# Résumé
Write-Host "RESUME"
Write-Host "================================================================================"
Write-Host ""

if ($test1Success) {
  Write-Host "Test 1: SUCCES"
} else {
  Write-Host "Test 1: ECHEC"
}

if ($test2Success) {
  Write-Host "Test 2: SUCCES"
} else {
  Write-Host "Test 2: ECHEC"
}

Write-Host ""
Write-Host "================================================================================"
Write-Host ""

if (-not ($test1Success -or $test2Success)) {
  Write-Host "INFORMATIONS POUR LE SUPPORT DASHDOC:"
  Write-Host ""
  Write-Host "Outil teste: PowerShell Invoke-RestMethod"
  Write-Host "Format auth: Authorization: Token $($API_KEY.Substring(0,20))..."
  Write-Host "IP source: 77.205.88.170"
  Write-Host ""
  Write-Host "Endpoints testes:"
  Write-Host "  1. $BASE_URL/transports/?page_size=1"
  Write-Host "  2. $BASE_URL/transports/?status=done&is_subcontracted=true&page_size=10"
  Write-Host ""
}
