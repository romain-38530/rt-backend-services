/**
 * Test pour trouver les statuts avec données complètes
 */

const axios = require('axios');

const API_KEY = '8321c7a8f7fe8f75192fa15a6c883a11758e0084';
const BASE_URL = 'https://api.dashdoc.eu/api/v4';

console.log('\n' + '='.repeat(80));
console.log('  TEST STATUTS AVEC DONNÉES COMPLÈTES');
console.log('='.repeat(80));
console.log();

async function testStatuts() {
  const statusToTest = ['done', 'verified', 'acknowledged', 'assigned', 'on_going', 'cancelled'];

  for (const status of statusToTest) {
    console.log(`\n${'─'.repeat(80)}`);
    console.log(`TEST: Status = ${status}`);
    console.log('─'.repeat(80));

    try {
      const response = await axios.get(`${BASE_URL}/transports/`, {
        headers: {
          'Authorization': `Token ${API_KEY}`,
          'Content-Type': 'application/json'
        },
        params: {
          business_status: 'orders',
          archived: false,
          status: status,
          page_size: 3
        },
        timeout: 15000
      });

      console.log(`✅ Count: ${response.data.count}`);

      if (response.data.results.length > 0) {
        const first = response.data.results[0];
        console.log(`  Premier affrètement:`);
        console.log(`    UID: ${first.uid}`);
        console.log(`    Route: ${first.origin?.address?.city || '?'} → ${first.destination?.address?.city || '?'}`);

        const price = first.charter?.price || first.subcontracting?.price;
        console.log(`    Prix: ${price ? price + '€' : 'Non trouvé'}`);

        const carrier = first.charter?.carrier || first.subcontracting?.carrier || first.carrier;
        console.log(`    Carrier: ${carrier ? carrier.name : 'Non trouvé'}`);

        const hasData = first.origin?.address?.postcode && first.destination?.address?.postcode && price && carrier;
        console.log(`    ✅ ${hasData ? 'Données COMPLÈTES' : 'Données INCOMPLÈTES'}`);
      }

    } catch (error) {
      console.log(`❌ Erreur: ${error.response?.status || error.message}`);
    }
  }

  console.log();
  console.log('='.repeat(80));
}

testStatuts().catch(error => {
  console.error('Erreur fatale:', error);
  process.exit(1);
});
