/**
 * Test pour générer et prévisualiser les templates d'email
 * Valide les modifications :
 * - TYPE 1 : Prix moyen retiré
 * - TYPE 2 : Offre changée en "10 consultations de transports gratuit"
 */

const fs = require('fs');
const path = require('path');

// Mock data pour transporteur
const mockCarrierData = {
  carrierName: 'MENIER TRANSPORTS',
  carrierEmail: 'elbad69@hotmail.fr',
  carrierContact: {
    firstName: 'Mohamed',
    lastName: 'SOLTANI'
  },
  totalTransports: 47,
  routes: [
    {
      from: '38790',
      fromCity: 'Saint-Georges-d\'Espéranche',
      to: '38070',
      toCity: 'Saint-Quentin-Fallavier',
      price: 12,
      date: new Date('2026-02-02')
    },
    {
      from: '13000',
      fromCity: 'Marseille',
      to: '69000',
      toCity: 'Lyon',
      price: 420,
      date: new Date('2026-01-28')
    },
    {
      from: '75000',
      fromCity: 'Paris',
      to: '33000',
      toCity: 'Bordeaux',
      price: 850,
      date: new Date('2026-01-15')
    }
  ],
  avgPrice: 384.5
};

// Mock offres disponibles
const mockAvailableOrders = [
  {
    orderId: 'ORDER-1',
    pickup: { city: 'Lyon', postalCode: '69000' },
    delivery: { city: 'Paris', postalCode: '75000' },
    pickupDate: new Date('2026-02-10'),
    estimatedPrice: 800,
    cargo: { palettes: 28, weight: 19000 }
  },
  {
    orderId: 'ORDER-2',
    pickup: { city: 'Marseille', postalCode: '13000' },
    delivery: { city: 'Bordeaux', postalCode: '33000' },
    pickupDate: new Date('2026-02-12'),
    estimatedPrice: 650,
    cargo: { palettes: 22, weight: 15000 }
  }
];

console.log('\n' + '='.repeat(80));
console.log('  TEST PREVIEW TEMPLATES EMAIL');
console.log('='.repeat(80));
console.log();

// Charger le service
const DashdocCarrierInvitationService = require('../services/dashdoc-carrier-invitation.service');

// URLs de test
const frontendUrl = 'https://symphonia.com';
const invitationToken = Buffer.from(JSON.stringify({
  carrierId: 'dashdoc-3991213',
  carrierName: mockCarrierData.carrierName,
  carrierEmail: mockCarrierData.carrierEmail
})).toString('base64url');

const invitationUrl = `${frontendUrl}/invitation/dashdoc/${invitationToken}`;
const signupUrl = `${frontendUrl}/signup/carrier?source=dashdoc&token=${invitationToken}`;

console.log('─'.repeat(80));
console.log('GÉNÉRATION EMAIL TYPE 1 (Transporteur Connu)');
console.log('─'.repeat(80));
console.log();

// Générer email TYPE 1
const emailType1 = DashdocCarrierInvitationService.generateKnownCarrierEmailHtml({
  carrierName: mockCarrierData.carrierName,
  contactName: `${mockCarrierData.carrierContact.firstName} ${mockCarrierData.carrierContact.lastName}`,
  totalTransports: mockCarrierData.totalTransports,
  routes: mockCarrierData.routes,
  avgPrice: mockCarrierData.avgPrice,
  invitationUrl
});

const previewPath1 = path.join(__dirname, 'preview-email-type1.html');
fs.writeFileSync(previewPath1, emailType1);
console.log(`✅ Email TYPE 1 généré (${emailType1.length} caractères)`);
console.log(`📄 Preview: ${previewPath1}`);
console.log();

// Vérifier que le prix moyen n'est PAS présent
if (emailType1.includes('Prix moyen')) {
  console.log('❌ ERREUR : Prix moyen détecté dans TYPE 1 (devrait être retiré)');
} else {
  console.log('✅ VALIDATION : Prix moyen correctement retiré du TYPE 1');
}
console.log();

// Vérifier le contenu attendu
const expectedType1Content = [
  `${mockCarrierData.totalTransports} transports réalisés`,
  'Accès prioritaire',
  'Négociation intelligente',
  'Zéro commission sur les 10 premiers transports',
  'Accéder à mon espace SYMPHONI.A'
];

console.log('Vérification contenu TYPE 1:');
expectedType1Content.forEach(content => {
  if (emailType1.includes(content)) {
    console.log(`  ✅ "${content}"`);
  } else {
    console.log(`  ❌ MANQUANT: "${content}"`);
  }
});

console.log();
console.log('─'.repeat(80));
console.log('GÉNÉRATION EMAIL TYPE 2 (Conquête)');
console.log('─'.repeat(80));
console.log();

// Générer email TYPE 2
const emailType2 = DashdocCarrierInvitationService.generateConquestEmailHtml({
  carrierName: mockCarrierData.carrierName,
  contactName: `${mockCarrierData.carrierContact.firstName} ${mockCarrierData.carrierContact.lastName}`,
  routes: mockCarrierData.routes.slice(0, 3),
  availableOrders: mockAvailableOrders,
  signupUrl
});

const previewPath2 = path.join(__dirname, 'preview-email-type2.html');
fs.writeFileSync(previewPath2, emailType2);
console.log(`✅ Email TYPE 2 généré (${emailType2.length} caractères)`);
console.log(`📄 Preview: ${previewPath2}`);
console.log();

// Vérifier que l'ancienne offre n'est PAS présente
if (emailType2.includes('transports SANS COMMISSION') || emailType2.includes('transports sans commission')) {
  console.log('❌ ERREUR : Ancienne offre "transports sans commission" détectée dans TYPE 2');
} else {
  console.log('✅ VALIDATION : Ancienne offre correctement retirée du TYPE 2');
}
console.log();

// Vérifier que la nouvelle offre EST présente
if (emailType2.includes('10 consultations de transports gratuit')) {
  console.log('✅ VALIDATION : Nouvelle offre "10 consultations de transports gratuit" présente dans TYPE 2');
} else {
  console.log('❌ ERREUR : Nouvelle offre "10 consultations de transports gratuit" MANQUANTE dans TYPE 2');
}
console.log();

if (emailType2.includes('20 consultations de transports gratuit')) {
  console.log('✅ VALIDATION : Offre limitée "20 consultations de transports gratuit" présente dans TYPE 2');
} else {
  console.log('❌ ERREUR : Offre limitée "20 consultations de transports gratuit" MANQUANTE dans TYPE 2');
}
console.log();

// Vérifier le contenu attendu
const expectedType2Content = [
  'Offres Disponibles sur Vos Routes',
  '10 consultations de transports gratuit',
  'Affret.IA - Votre Assistant Personnel',
  'Créer mon compte gratuitement',
  '20 consultations de transports gratuit'
];

console.log('Vérification contenu TYPE 2:');
expectedType2Content.forEach(content => {
  if (emailType2.includes(content)) {
    console.log(`  ✅ "${content}"`);
  } else {
    console.log(`  ❌ MANQUANT: "${content}"`);
  }
});

console.log();
console.log('='.repeat(80));
console.log('  RÉSUMÉ');
console.log('='.repeat(80));
console.log();

const validations = {
  type1PrixMoyenRetire: !emailType1.includes('Prix moyen'),
  type1ContenusPresents: expectedType1Content.every(c => emailType1.includes(c)),
  type2AncienneOffreRetiree: !emailType2.includes('transports SANS COMMISSION') && !emailType2.includes('transports sans commission'),
  type2NouvelleOffrePresente: emailType2.includes('10 consultations de transports gratuit'),
  type2OffreLimiteePresente: emailType2.includes('20 consultations de transports gratuit'),
  type2ContenusPresents: expectedType2Content.every(c => emailType2.includes(c))
};

const allValid = Object.values(validations).every(v => v === true);

if (allValid) {
  console.log('✅ TOUS LES TESTS RÉUSSIS !');
  console.log();
  console.log('Modifications validées:');
  console.log('  ✅ TYPE 1 : Prix moyen retiré');
  console.log('  ✅ TYPE 2 : Offre changée en "10 consultations de transports gratuit"');
  console.log();
  console.log('📝 Prochaines étapes:');
  console.log('1. Ouvrir les previews dans navigateur:');
  console.log(`   - ${previewPath1}`);
  console.log(`   - ${previewPath2}`);
  console.log('2. Valider visuellement les emails');
  console.log('3. Déployer le service sur AWS EB');
  console.log('4. Lancer campagne test avec 5-10 invitations');
} else {
  console.log('❌ CERTAINS TESTS ONT ÉCHOUÉ');
  console.log();
  console.log('Détails:');
  Object.entries(validations).forEach(([key, value]) => {
    console.log(`  ${value ? '✅' : '❌'} ${key}`);
  });
}

console.log();
console.log('='.repeat(80));
console.log();
