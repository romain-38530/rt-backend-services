/**
 * Test FINAL de l'import Dashdoc avec tous les filtres et extractions corrects
 */

const axios = require('axios');

const API_KEY = '8321c7a8f7fe8f75192fa15a6c883a11758e0084';
const BASE_URL = 'https://api.dashdoc.eu/api/v4';

console.log('\n' + '='.repeat(80));
console.log('  TEST FINAL IMPORT DASHDOC');
console.log('='.repeat(80));
console.log();

async function testFinalImport() {
  console.log('Configuration:');
  console.log(`  URL: ${BASE_URL}`);
  console.log(`  Auth: Token (pas Bearer)`);
  console.log(`  Filtre: business_status=orders, archived=false`);
  console.log();

  try {
    // Récupérer 10 affrètements en sample
    const response = await axios.get(`${BASE_URL}/transports/`, {
      headers: {
        'Authorization': `Token ${API_KEY}`,
        'Content-Type': 'application/json'
      },
      params: {
        business_status: 'orders',  // ✅ Affrètements uniquement
        archived: false,            // ✅ Non archivés
        page_size: 10               // 10 pour tester
      },
      timeout: 15000
    });

    console.log('─'.repeat(80));
    console.log(`✅ SUCCÈS - HTTP ${response.status}`);
    console.log(`📊 Total affrètements disponibles: ${response.data.count.toLocaleString('fr-FR')}`);
    console.log(`📦 Affrètements retournés (sample): ${response.data.results.length}`);
    console.log();

    // Analyser les 10 premiers
    console.log('─'.repeat(80));
    console.log('ANALYSE DES 10 PREMIERS AFFRÈTEMENTS:');
    console.log('─'.repeat(80));
    console.log();

    let validCount = 0;
    let invalidCount = 0;
    const issues = [];

    for (const transport of response.data.results) {
      console.log(`Transport ${transport.uid}:`);
      console.log(`  Status: ${transport.status || 'N/A'}`);

      // Vérifier route
      const hasRoute = transport.origin?.address?.postcode && transport.destination?.address?.postcode;
      console.log(`  Route: ${hasRoute ? '✅' : '❌'} ${transport.origin?.address?.city || '?'} → ${transport.destination?.address?.city || '?'}`);

      // Vérifier prix sous-traitant
      const chartPrice = transport.charter?.price;
      const subPrice = transport.subcontracting?.price;
      const hasPrice = chartPrice || subPrice;
      const price = chartPrice || subPrice;

      if (hasPrice) {
        console.log(`  Prix sous-traitant: ✅ ${price}€ (source: ${chartPrice ? 'charter.price' : 'subcontracting.price'})`);
      } else {
        console.log(`  Prix sous-traitant: ❌ Non trouvé`);
      }

      // Vérifier palettes
      const palettes = transport.pallets_count;
      console.log(`  Palettes: ${palettes || 0}`);

      // Vérifier carrier
      const carrier = transport.charter?.carrier || transport.subcontracting?.carrier || transport.carrier;
      if (carrier) {
        console.log(`  Transporteur: ✅ ${carrier.name || 'N/A'}`);
        console.log(`    ID: ${carrier.pk || 'N/A'}`);
        console.log(`    Email: ${carrier.email || carrier.contact_email || 'N/A'}`);
        console.log(`    Phone: ${carrier.phone || carrier.contact_phone || 'N/A'}`);
      } else {
        console.log(`  Transporteur: ❌ Non trouvé`);
      }

      // Validation globale
      if (hasRoute && hasPrice && carrier) {
        console.log(`  ✅ VALIDE pour import`);
        validCount++;
      } else {
        console.log(`  ❌ INVALIDE pour import`);
        invalidCount++;

        if (!hasRoute) issues.push('Route incomplète');
        if (!hasPrice) issues.push('Pas de prix sous-traitant');
        if (!carrier) issues.push('Pas de transporteur');
      }

      console.log();
    }

    // Résumé
    console.log('='.repeat(80));
    console.log('RÉSUMÉ DE L\'ANALYSE:');
    console.log('='.repeat(80));
    console.log();
    console.log(`Affrètements analysés: 10`);
    console.log(`✅ Valides pour import: ${validCount}`);
    console.log(`❌ Invalides: ${invalidCount}`);
    console.log();

    if (invalidCount > 0) {
      console.log(`Problèmes détectés:`);
      const uniqueIssues = [...new Set(issues)];
      uniqueIssues.forEach(issue => {
        console.log(`  - ${issue}`);
      });
      console.log();
    }

    const successRate = (validCount / 10) * 100;
    console.log(`Taux de succès: ${successRate}%`);
    console.log();

    if (successRate >= 80) {
      console.log('✅ EXCELLENT ! L\'import est prêt.');
      console.log();
      console.log('Sur les 8 371 affrètements, environ:', Math.round(response.data.count * (successRate / 100)).toLocaleString('fr-FR'), 'seront importés');
      console.log();
    } else if (successRate >= 50) {
      console.log('⚠️ BON. Mais des améliorations sont possibles.');
      console.log();
    } else {
      console.log('❌ ATTENTION. Beaucoup d\'affrètements seront ignorés.');
      console.log();
    }

    console.log('='.repeat(80));
    console.log('PROCHAINES ÉTAPES:');
    console.log('='.repeat(80));
    console.log();
    console.log('1. Déployer le code mis à jour en production');
    console.log('2. Mettre à jour les variables d\'environnement AWS:');
    console.log('   - DASHDOC_API_URL=https://api.dashdoc.eu/api/v4');
    console.log('   - DASHDOC_API_KEY=8321c7a8f7fe8f75192fa15a6c883a11758e0084');
    console.log('3. Tester l\'import en dry-run:');
    console.log('   POST /api/v1/affretia/import/dashdoc');
    console.log('   { "organizationId": "test", "months": 6, "dryRun": true }');
    console.log('4. Import réel si dry-run OK');
    console.log();

  } catch (error) {
    console.log('❌ ÉCHEC');
    console.log();

    if (error.response) {
      console.log(`HTTP Status: ${error.response.status}`);
      console.log(`Response:`, JSON.stringify(error.response.data, null, 2));
    } else {
      console.log(`Error:`, error.message);
    }
  }
}

testFinalImport().catch(error => {
  console.error('Erreur fatale:', error);
  process.exit(1);
});
