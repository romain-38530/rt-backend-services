/**
 * Test d'import Dashdoc avec la NOUVELLE structure d'extraction
 * Valide que les données sont correctement extraites depuis:
 * - deliveries[0].origin.address et deliveries[0].destination.address (routes)
 * - deliveries[0].loads[0] (cargo: palettes, poids)
 * - deliveries[0].tracking_contacts[0].contact (carrier contact)
 * - carrier_address (carrier info)
 * - agreed_price_total, effective_price_total, etc. (prix)
 */

const axios = require('axios');

const API_KEY = '8321c7a8f7fe8f75192fa15a6c883a11758e0084';
const BASE_URL = 'https://api.dashdoc.eu/api/v4';

console.log('\n' + '='.repeat(80));
console.log('  TEST IMPORT DASHDOC - NOUVELLE STRUCTURE');
console.log('='.repeat(80));
console.log();

// Simuler les méthodes d'extraction refactorisées
function extractCarrierPrice(transport) {
  // Priorité 1: purchase_cost_total
  if (transport.purchase_cost_total) {
    return {
      price: parseFloat(transport.purchase_cost_total),
      currency: transport.currency || 'EUR',
      source: 'purchase_cost_total',
      found: true
    };
  }

  // Priorité 2: agreed_price_total
  if (transport.agreed_price_total) {
    return {
      price: parseFloat(transport.agreed_price_total),
      currency: transport.currency || 'EUR',
      source: 'agreed_price_total',
      found: true
    };
  }

  // Priorité 3: effective_price_total
  if (transport.effective_price_total) {
    return {
      price: parseFloat(transport.effective_price_total),
      currency: transport.currency || 'EUR',
      source: 'effective_price_total',
      found: true
    };
  }

  // Priorité 4: pricing_total_price
  if (transport.pricing_total_price) {
    return {
      price: parseFloat(transport.pricing_total_price),
      currency: transport.currency || 'EUR',
      source: 'pricing_total_price',
      found: true
    };
  }

  return {
    price: null,
    currency: 'EUR',
    source: 'none',
    found: false
  };
}

function extractCarrierInfo(transport) {
  let carrierData = null;
  let contactData = null;
  let source = null;

  // Priorité 1: carrier_address
  if (transport.carrier_address?.company) {
    carrierData = {
      pk: transport.carrier_address.company.pk,
      name: transport.carrier_address.company.name || transport.carrier_address.name,
      siren: transport.carrier_address.company.siren || transport.carrier_address.company.trade_number,
      phone: transport.carrier_address.company.phone_number,
      email: transport.carrier_address.company.email || null,
      address: {
        address: transport.carrier_address.address,
        city: transport.carrier_address.city,
        postalCode: transport.carrier_address.postcode,
        country: transport.carrier_address.country || 'FR'
      }
    };
    source = 'carrier_address';
  }

  // Priorité 2: deliveries[0].tracking_contacts[0].contact
  if (transport.deliveries && transport.deliveries.length > 0) {
    const delivery = transport.deliveries[0];

    if (delivery.tracking_contacts && delivery.tracking_contacts.length > 0) {
      const trackingContact = delivery.tracking_contacts.find(tc => tc.role === 'carrier');

      if (trackingContact?.contact) {
        contactData = {
          email: trackingContact.contact.email,
          phone: trackingContact.contact.phone_number,
          firstName: trackingContact.contact.first_name,
          lastName: trackingContact.contact.last_name
        };

        // Si pas de carrier_address, utiliser tracking_contact
        if (!carrierData && trackingContact.contact.company) {
          carrierData = {
            pk: trackingContact.contact.company.pk,
            name: trackingContact.contact.company.name,
            siren: trackingContact.contact.company.trade_number,
            phone: trackingContact.contact.company.phone_number,
            email: trackingContact.contact.email,
            address: null
          };
          source = 'tracking_contacts';
        }
      }
    }
  }

  if (!carrierData) {
    return null;
  }

  return {
    pk: carrierData.pk,
    name: carrierData.name || 'Transporteur',
    email: contactData?.email || carrierData.email || null,
    phone: contactData?.phone || carrierData.phone || null,
    siren: carrierData.siren || null,
    address: carrierData.address || null,
    contact: contactData ? {
      firstName: contactData.firstName,
      lastName: contactData.lastName,
      email: contactData.email,
      phone: contactData.phone
    } : null,
    source: source
  };
}

async function testImportNewStructure() {
  console.log('🔍 Récupération de 10 affrètements status=done...\n');

  try {
    const response = await axios.get(`${BASE_URL}/transports/`, {
      headers: {
        'Authorization': `Token ${API_KEY}`,
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      params: {
        business_status: 'orders',
        archived: false,
        status: 'done',  // Seulement les terminés
        page_size: 10
      },
      timeout: 15000
    });

    const transports = response.data.results || [];
    console.log(`✅ ${transports.length} transports récupérés\n`);

    let validCount = 0;
    let invalidCount = 0;

    for (const transport of transports) {
      console.log(`${'─'.repeat(80)}`);
      console.log(`Transport: ${transport.uid}`);
      console.log(`Status: ${transport.status}`);
      console.log();

      // Extraire delivery
      const delivery = transport.deliveries && transport.deliveries.length > 0 ? transport.deliveries[0] : null;

      if (!delivery) {
        console.log('❌ Pas de delivery');
        invalidCount++;
        continue;
      }

      // Extraire adresses
      const pickupAddress = delivery.origin?.address;
      const deliveryAddress = delivery.destination?.address;

      if (!pickupAddress || !deliveryAddress) {
        console.log('❌ Adresses manquantes');
        invalidCount++;
        continue;
      }

      console.log('📍 Route:');
      console.log(`   Origine: ${pickupAddress.city} (${pickupAddress.postcode})`);
      console.log(`   Destination: ${deliveryAddress.city} (${deliveryAddress.postcode})`);

      // Extraire cargo
      const loads = delivery.loads && delivery.loads.length > 0 ? delivery.loads[0] : null;

      if (loads) {
        console.log();
        console.log('📦 Cargo:');
        console.log(`   Palettes: ${loads.quantity || 0}`);
        console.log(`   Poids: ${loads.weight || 0} kg`);
        console.log(`   Volume: ${loads.volume || 0} m³`);
        console.log(`   Type: ${loads.category || 'N/A'}`);
      } else {
        console.log();
        console.log('⚠️ Pas de cargo (loads)');
      }

      // Extraire prix
      const carrierPricing = extractCarrierPrice(transport);

      console.log();
      console.log('💰 Prix:');
      if (carrierPricing.found) {
        console.log(`   Prix: ${carrierPricing.price}€`);
        console.log(`   Source: ${carrierPricing.source}`);
        console.log(`   Devise: ${carrierPricing.currency}`);
      } else {
        console.log('   ❌ Pas de prix trouvé');
      }

      // Extraire carrier info
      const carrierInfo = extractCarrierInfo(transport);

      console.log();
      console.log('🚛 Transporteur:');
      if (carrierInfo) {
        console.log(`   Nom: ${carrierInfo.name}`);
        console.log(`   PK: ${carrierInfo.pk}`);
        console.log(`   Email: ${carrierInfo.email || 'N/A'}`);
        console.log(`   Téléphone: ${carrierInfo.phone || 'N/A'}`);
        console.log(`   SIREN: ${carrierInfo.siren || 'N/A'}`);
        console.log(`   Source: ${carrierInfo.source}`);

        if (carrierInfo.contact) {
          console.log(`   Contact: ${carrierInfo.contact.firstName} ${carrierInfo.contact.lastName}`);
        }

        if (carrierInfo.address) {
          console.log(`   Adresse: ${carrierInfo.address.city} (${carrierInfo.address.postalCode})`);
        }
      } else {
        console.log('   ❌ Pas de carrier trouvé');
      }

      // Valider affrètement
      const isValid = pickupAddress?.postcode &&
                      deliveryAddress?.postcode &&
                      carrierInfo &&
                      carrierPricing.found &&
                      carrierPricing.price > 0;

      console.log();
      if (isValid) {
        console.log('✅ VALIDE - Affrètement importable');
        validCount++;
      } else {
        console.log('❌ INVALIDE - Données manquantes');
        invalidCount++;
      }

      console.log();
    }

    console.log('='.repeat(80));
    console.log('  RÉSUMÉ');
    console.log('='.repeat(80));
    console.log();
    console.log(`Total transports: ${transports.length}`);
    console.log(`✅ Valides: ${validCount}`);
    console.log(`❌ Invalides: ${invalidCount}`);
    console.log();

    if (validCount > 0) {
      console.log(`🎉 ${validCount}/${transports.length} affrètements peuvent être importés !`);
      console.log();
      console.log('📝 PROCHAINES ÉTAPES:');
      console.log('1. Déployer le nouveau code pricing.service.js');
      console.log('2. Lancer l\'import complet des 8371 affrètements');
      console.log('3. Vérifier dans MongoDB les données importées');
    } else {
      console.log('⚠️ Aucun affrètement valide trouvé');
      console.log('Vérifier les filtres de l\'API Dashdoc');
    }

    console.log();

  } catch (error) {
    console.error('❌ Erreur:', error.message);
    if (error.response) {
      console.error('Response:', error.response.status, error.response.data);
    }
    process.exit(1);
  }
}

testImportNewStructure();
