/**
 * Test pour récupérer uniquement les AFFRÈTEMENTS (business_status=orders)
 * Objectif : récupérer les 8371 affrètements visibles dans l'interface
 */

const axios = require('axios');

const API_KEY = '8321c7a8f7fe8f75192fa15a6c883a11758e0084';
const BASE_URL = 'https://api.dashdoc.eu/api/v4';

console.log('\n' + '='.repeat(80));
console.log('  TEST AFFRÈTEMENTS DASHDOC');
console.log('='.repeat(80));
console.log();
console.log('Objectif: Récupérer les 8371 affrètements visibles dans l\'interface');
console.log();

async function testAffretements() {
  const tests = [
    // Test 1: business_status=orders
    {
      name: 'Affrètements (business_status=orders)',
      params: { business_status: 'orders', page_size: 1 }
    },

    // Test 2: business_status=orders + tous statuts
    {
      name: 'Affrètements tous statuts',
      params: { business_status: 'orders', page_size: 1 }
    },

    // Test 3: archived=false (non archivés)
    {
      name: 'Transports non archivés',
      params: { archived: false, page_size: 1 }
    },

    // Test 4: business_status=orders + archived=false
    {
      name: 'Affrètements non archivés',
      params: { business_status: 'orders', archived: false, page_size: 1 }
    },

    // Test 5: Affrètements + sous-traités
    {
      name: 'Affrètements sous-traités',
      params: { business_status: 'orders', is_subcontracted: true, page_size: 1 }
    },

    // Test 6: Affrètements terminés
    {
      name: 'Affrètements terminés (status=done)',
      params: { business_status: 'orders', status: 'done', page_size: 1 }
    },

    // Test 7: Affrètements terminés + sous-traités
    {
      name: 'Affrètements terminés + sous-traités',
      params: { business_status: 'orders', status: 'done', is_subcontracted: true, page_size: 1 }
    },

    // Test 8: Essayer avec tab=orders
    {
      name: 'tab=orders (alternative)',
      params: { tab: 'orders', page_size: 1 }
    },

    // Test 9: Essayer order_status
    {
      name: 'order_status parameter',
      params: { order_status: 'confirmed', page_size: 1 }
    },

    // Test 10: Vérifier les différents statuts possibles
    {
      name: 'Status: verified',
      params: { status: 'verified', page_size: 1 }
    },

    {
      name: 'Status: acknowledged',
      params: { status: 'acknowledged', page_size: 1 }
    },

    {
      name: 'Status: assigned',
      params: { status: 'assigned', page_size: 1 }
    },

    {
      name: 'Status: on_going',
      params: { status: 'on_going', page_size: 1 }
    },

    {
      name: 'Status: done',
      params: { status: 'done', page_size: 1 }
    }
  ];

  const results = [];

  for (const test of tests) {
    console.log(`\n${'─'.repeat(80)}`);
    console.log(`TEST: ${test.name}`);
    console.log('─'.repeat(80));
    console.log('Params:', JSON.stringify(test.params));
    console.log();

    try {
      const response = await axios.get(`${BASE_URL}/transports/`, {
        headers: {
          'Authorization': `Token ${API_KEY}`,
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        params: test.params,
        timeout: 15000
      });

      const count = response.data.count;
      console.log(`✅ Résultat: ${count.toLocaleString('fr-FR')} transports`);

      // Afficher le premier résultat pour voir la structure
      if (response.data.results && response.data.results.length > 0) {
        const first = response.data.results[0];
        console.log('   Premier transport:');
        console.log(`     UID: ${first.uid}`);
        console.log(`     Status: ${first.status}`);
        if (first.business_status) console.log(`     Business status: ${first.business_status}`);
        if (first.archived !== undefined) console.log(`     Archived: ${first.archived}`);
        if (first.charter?.price) console.log(`     Prix charter: ${first.charter.price}€`);
      }

      results.push({
        name: test.name,
        params: test.params,
        count: count,
        success: true
      });

    } catch (error) {
      if (error.response) {
        console.log(`❌ Erreur HTTP ${error.response.status}: ${JSON.stringify(error.response.data)}`);
      } else {
        console.log(`❌ Erreur: ${error.message}`);
      }
      results.push({
        name: test.name,
        params: test.params,
        count: 0,
        success: false,
        error: error.message
      });
    }
  }

  // Tableau récapitulatif
  console.log();
  console.log('='.repeat(80));
  console.log('  TABLEAU RÉCAPITULATIF');
  console.log('='.repeat(80));
  console.log();

  console.log('| Filtre | Transports | Params |');
  console.log('|--------|------------|--------|');
  results.forEach(r => {
    if (r.success) {
      const countStr = r.count.toLocaleString('fr-FR').padStart(10);
      const paramsStr = JSON.stringify(r.params);
      console.log(`| ${r.name.padEnd(40)} | ${countStr} | ${paramsStr} |`);
    } else {
      console.log(`| ${r.name.padEnd(40)} | ❌ ERREUR  | ${r.error} |`);
    }
  });

  console.log();
  console.log('='.repeat(80));
  console.log();

  // Trouver le filtre qui donne ~8371
  const target = 8371;
  const closest = results
    .filter(r => r.success)
    .reduce((prev, curr) => {
      return Math.abs(curr.count - target) < Math.abs(prev.count - target) ? curr : prev;
    }, { count: 0 });

  if (closest.count > 0) {
    console.log(`🎯 Filtre le PLUS PROCHE de 8371 affrètements:`);
    console.log(`   ${closest.name}: ${closest.count.toLocaleString('fr-FR')} transports`);
    console.log(`   Params: ${JSON.stringify(closest.params)}`);
    console.log();

    if (Math.abs(closest.count - target) < 500) {
      console.log('✅ Ce filtre correspond bien aux affrètements visibles dans l\'interface !');
    } else {
      console.log(`⚠️ Écart de ${Math.abs(closest.count - target).toLocaleString('fr-FR')} transports par rapport à l\'interface`);
    }
  }

  console.log();
}

testAffretements().catch(error => {
  console.error('Erreur fatale:', error);
  process.exit(1);
});
