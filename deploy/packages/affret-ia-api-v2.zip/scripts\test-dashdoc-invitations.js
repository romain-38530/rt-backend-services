/**
 * Test du système d'invitation transporteurs Dashdoc
 * Valide :
 * 1. Identification carriers non présents dans Symphonia
 * 2. Génération tokens d'invitation
 * 3. Génération emails HTML (TYPE 1 et TYPE 2)
 * 4. Envoi email dry-run
 */

require('dotenv').config();
const mongoose = require('mongoose');
const DashdocCarrierInvitationService = require('../services/dashdoc-carrier-invitation.service');
const PriceHistory = require('../models/PriceHistory');

console.log('\n' + '='.repeat(80));
console.log('  TEST SYSTÈME INVITATION DASHDOC');
console.log('='.repeat(80));
console.log();

async function testInvitationSystem() {
  try {
    // Connexion MongoDB
    console.log('📦 Connexion MongoDB...');
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/affret-ia');
    console.log('✅ MongoDB connecté\n');

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 1: Identifier carriers Dashdoc non présents dans Symphonia
    // ═══════════════════════════════════════════════════════════════════════

    console.log('─'.repeat(80));
    console.log('TEST 1: IDENTIFICATION CARRIERS NON PRÉSENTS DANS SYMPHONIA');
    console.log('─'.repeat(80));
    console.log();

    const identification = await DashdocCarrierInvitationService.identifyDashdocCarriersNotInSymphonia();

    console.log(`📊 Résultats:`);
    console.log(`   Total carriers Dashdoc: ${identification.total}`);
    console.log(`   Non présents dans Symphonia: ${identification.notInSymphonia}`);
    console.log(`   Taux de non-présence: ${((identification.notInSymphonia / identification.total) * 100).toFixed(1)}%`);
    console.log();

    if (identification.carriers.length > 0) {
      console.log('📋 Top 5 carriers à inviter:');
      identification.carriers.slice(0, 5).forEach((carrier, i) => {
        console.log(`   ${i+1}. ${carrier.carrierName}`);
        console.log(`      Email: ${carrier.carrierEmail || 'N/A'}`);
        console.log(`      Transports: ${carrier.totalTransports}`);
        console.log(`      Routes: ${carrier.routes.length}`);
        console.log(`      Prix moyen: ${carrier.avgPrice.toFixed(2)}€`);
        console.log();
      });
    }

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 2: Générer token d'invitation
    // ═══════════════════════════════════════════════════════════════════════

    if (identification.carriers.length === 0) {
      console.log('⚠️ Aucun carrier à tester, fin du test');
      process.exit(0);
    }

    const testCarrier = identification.carriers[0];

    console.log('─'.repeat(80));
    console.log('TEST 2: GÉNÉRATION TOKEN INVITATION');
    console.log('─'.repeat(80));
    console.log();

    const invitationToken = DashdocCarrierInvitationService.generateInvitationToken(testCarrier);
    console.log(`✅ Token généré (${invitationToken.length} caractères):`);
    console.log(`   ${invitationToken.substring(0, 50)}...`);
    console.log();

    // Décoder le token pour vérifier
    const decodedToken = JSON.parse(Buffer.from(invitationToken, 'base64url').toString());
    console.log(`📋 Contenu du token:`);
    console.log(`   Carrier: ${decodedToken.carrierName}`);
    console.log(`   Email: ${decodedToken.carrierEmail}`);
    console.log(`   SIREN: ${decodedToken.carrierSiren}`);
    console.log(`   Expire: ${new Date(decodedToken.expiresAt).toLocaleDateString('fr-FR')}`);
    console.log();

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 3: Générer email TYPE 1 (transporteur connu)
    // ═══════════════════════════════════════════════════════════════════════

    console.log('─'.repeat(80));
    console.log('TEST 3: GÉNÉRATION EMAIL TYPE 1 (TRANSPORTEUR CONNU)');
    console.log('─'.repeat(80));
    console.log();

    const frontendUrl = process.env.FRONTEND_URL || 'https://symphonia.com';
    const invitationUrl = `${frontendUrl}/invitation/dashdoc/${invitationToken}`;

    const emailType1 = DashdocCarrierInvitationService.generateKnownCarrierEmailHtml({
      carrierName: testCarrier.carrierName,
      contactName: testCarrier.carrierContact ?
        `${testCarrier.carrierContact.firstName} ${testCarrier.carrierContact.lastName}` :
        null,
      totalTransports: testCarrier.totalTransports,
      routes: testCarrier.routes.slice(0, 5),
      avgPrice: testCarrier.avgPrice,
      invitationUrl
    });

    console.log(`✅ Email TYPE 1 généré (${emailType1.length} caractères)`);
    console.log(`   Destinataire: ${testCarrier.carrierName}`);
    console.log(`   Email: ${testCarrier.carrierEmail}`);
    console.log(`   Lien invitation: ${invitationUrl}`);
    console.log();

    // Sauvegarder HTML pour inspection visuelle
    const fs = require('fs');
    const previewPath = './scripts/preview-email-type1.html';
    fs.writeFileSync(previewPath, emailType1);
    console.log(`📄 Preview sauvegardé: ${previewPath}`);
    console.log();

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 4: Générer email TYPE 2 (conquête)
    // ═══════════════════════════════════════════════════════════════════════

    console.log('─'.repeat(80));
    console.log('TEST 4: GÉNÉRATION EMAIL TYPE 2 (CONQUÊTE)');
    console.log('─'.repeat(80));
    console.log();

    const signupUrl = `${frontendUrl}/signup/carrier?source=dashdoc&token=${invitationToken}`;

    // Simuler offres disponibles
    const mockAvailableOrders = testCarrier.routes.slice(0, 3).map((route, i) => ({
      orderId: `MOCK-${i+1}`,
      pickup: {
        city: route.fromCity,
        postalCode: route.from
      },
      delivery: {
        city: route.toCity,
        postalCode: route.to
      },
      pickupDate: new Date(Date.now() + (i+2) * 24 * 60 * 60 * 1000),
      estimatedPrice: Math.floor(route.price * (0.9 + Math.random() * 0.2)),
      cargo: {
        palettes: Math.floor(Math.random() * 30) + 10,
        weight: Math.floor(Math.random() * 20000) + 5000
      }
    }));

    const emailType2 = DashdocCarrierInvitationService.generateConquestEmailHtml({
      carrierName: testCarrier.carrierName,
      contactName: testCarrier.carrierContact ?
        `${testCarrier.carrierContact.firstName} ${testCarrier.carrierContact.lastName}` :
        null,
      routes: testCarrier.routes.slice(0, 3),
      availableOrders: mockAvailableOrders,
      signupUrl
    });

    console.log(`✅ Email TYPE 2 généré (${emailType2.length} caractères)`);
    console.log(`   Destinataire: ${testCarrier.carrierName}`);
    console.log(`   Offres disponibles: ${mockAvailableOrders.length}`);
    console.log(`   Lien inscription: ${signupUrl}`);
    console.log();

    // Sauvegarder HTML
    const previewPath2 = './scripts/preview-email-type2.html';
    fs.writeFileSync(previewPath2, emailType2);
    console.log(`📄 Preview sauvegardé: ${previewPath2}`);
    console.log();

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 5: Envoi email DRY-RUN (TYPE 1)
    // ═══════════════════════════════════════════════════════════════════════

    console.log('─'.repeat(80));
    console.log('TEST 5: ENVOI EMAIL DRY-RUN (TYPE 1)');
    console.log('─'.repeat(80));
    console.log();

    if (!testCarrier.carrierEmail) {
      console.log('⚠️ Pas d\'email pour ce carrier, test ignoré');
    } else {
      const sendResult = await DashdocCarrierInvitationService.sendInvitationToKnownCarrier(
        testCarrier,
        { dryRun: true }
      );

      if (sendResult.success) {
        console.log('✅ Email DRY-RUN réussi');
        console.log(`   Token: ${sendResult.invitationToken.substring(0, 30)}...`);
        console.log(`   URL: ${sendResult.invitationUrl}`);
      } else {
        console.log('❌ Email DRY-RUN échoué:', sendResult.error || sendResult.reason);
      }
    }
    console.log();

    // ═══════════════════════════════════════════════════════════════════════
    // TEST 6: Statistiques globales
    // ═══════════════════════════════════════════════════════════════════════

    console.log('─'.repeat(80));
    console.log('TEST 6: STATISTIQUES GLOBALES');
    console.log('─'.repeat(80));
    console.log();

    const stats = {
      totalCarriers: identification.total,
      carriersToInvite: identification.notInSymphonia,
      carriersWithEmail: identification.carriers.filter(c => c.carrierEmail).length,
      carriersWithoutEmail: identification.carriers.filter(c => !c.carrierEmail).length,
      totalTransports: identification.carriers.reduce((sum, c) => sum + c.totalTransports, 0),
      avgTransportsPerCarrier: identification.carriers.length > 0 ?
        (identification.carriers.reduce((sum, c) => sum + c.totalTransports, 0) / identification.carriers.length).toFixed(1) :
        0
    };

    console.log('📊 Statistiques:');
    console.log(`   Total carriers Dashdoc: ${stats.totalCarriers}`);
    console.log(`   À inviter: ${stats.carriersToInvite} (${((stats.carriersToInvite / stats.totalCarriers) * 100).toFixed(1)}%)`);
    console.log(`   Avec email: ${stats.carriersWithEmail} (${((stats.carriersWithEmail / stats.carriersToInvite) * 100).toFixed(1)}%)`);
    console.log(`   Sans email: ${stats.carriersWithoutEmail}`);
    console.log(`   Transports total: ${stats.totalTransports}`);
    console.log(`   Moyenne transports/carrier: ${stats.avgTransportsPerCarrier}`);
    console.log();

    console.log('💡 Potentiel:');
    const invitableCarriers = stats.carriersWithEmail;
    console.log(`   Carriers invitables immédiatement: ${invitableCarriers}`);
    console.log(`   Si 10% acceptent: ${Math.floor(invitableCarriers * 0.1)} nouveaux transporteurs`);
    console.log(`   Si 20% acceptent: ${Math.floor(invitableCarriers * 0.2)} nouveaux transporteurs`);
    console.log(`   Si 30% acceptent: ${Math.floor(invitableCarriers * 0.3)} nouveaux transporteurs`);
    console.log();

    // ═══════════════════════════════════════════════════════════════════════
    // Résumé final
    // ═══════════════════════════════════════════════════════════════════════

    console.log('='.repeat(80));
    console.log('  RÉSUMÉ FINAL');
    console.log('='.repeat(80));
    console.log();

    console.log('✅ Tous les tests ont réussi !');
    console.log();
    console.log('📝 Prochaines étapes:');
    console.log('1. Configurer SMTP dans les variables d\'environnement:');
    console.log('   - SMTP_HOST');
    console.log('   - SMTP_PORT');
    console.log('   - SMTP_USER');
    console.log('   - SMTP_PASS');
    console.log();
    console.log('2. Vérifier les previews HTML générés:');
    console.log(`   - ${previewPath}`);
    console.log(`   - ${previewPath2}`);
    console.log();
    console.log('3. Lancer une campagne test avec 5-10 invitations:');
    console.log('   POST /api/v1/dashdoc-invitations/campaign');
    console.log('   Body: { "type": "known", "maxInvitations": 10, "dryRun": true }');
    console.log();
    console.log('4. Après validation, lancer la campagne complète:');
    console.log(`   Body: { "type": "known", "maxInvitations": ${invitableCarriers}, "dryRun": false }`);
    console.log();

  } catch (error) {
    console.error('❌ Erreur:', error);
    process.exit(1);
  } finally {
    await mongoose.disconnect();
    console.log('📦 MongoDB déconnecté');
  }
}

testInvitationSystem();
