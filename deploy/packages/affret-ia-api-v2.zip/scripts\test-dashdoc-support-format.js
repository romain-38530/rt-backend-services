/**
 * Test avec le format EXACT fourni par le support Dashdoc
 * Format confirmé: Authorization: Token <token>
 */

const axios = require('axios');

const API_KEY = '8321c7a8f7fe8f75192fa15a6c883a11758e0084';
const BASE_URL = 'https://api.dashdoc.com/api/v4';

console.log('\n' + '='.repeat(80));
console.log('  TEST AVEC FORMAT EXACT DU SUPPORT DASHDOC');
console.log('='.repeat(80));
console.log();
console.log(`Clé API: ${API_KEY.substring(0, 20)}...`);
console.log(`Format: Authorization: Token <token>`);
console.log(`Base URL: ${BASE_URL}`);
console.log();

async function testDashdocAPI() {
  const tests = [
    // Test 1: Endpoint /transports/ (liste transports)
    {
      name: 'GET /transports/ (page_size=1)',
      config: {
        method: 'GET',
        url: `${BASE_URL}/transports/`,
        headers: {
          'Authorization': `Token ${API_KEY}`,
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        params: {
          page_size: 1
        },
        timeout: 15000
      }
    },

    // Test 2: Endpoint /transports/ avec filtres (notre cas d'usage)
    {
      name: 'GET /transports/ (status=done, is_subcontracted=true)',
      config: {
        method: 'GET',
        url: `${BASE_URL}/transports/`,
        headers: {
          'Authorization': `Token ${API_KEY}`,
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        params: {
          status: 'done',
          is_subcontracted: true,
          page_size: 10
        },
        timeout: 15000
      }
    },

    // Test 3: Endpoint /transports/ avec période (6 derniers mois)
    {
      name: 'GET /transports/ (6 derniers mois)',
      config: {
        method: 'GET',
        url: `${BASE_URL}/transports/`,
        headers: {
          'Authorization': `Token ${API_KEY}`,
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        params: {
          status: 'done',
          is_subcontracted: true,
          created_after: new Date(Date.now() - 180 * 24 * 60 * 60 * 1000).toISOString(),
          page_size: 100
        },
        timeout: 15000
      }
    }
  ];

  let successCount = 0;

  for (const test of tests) {
    console.log(`\n${'─'.repeat(80)}`);
    console.log(`TEST: ${test.name}`);
    console.log('─'.repeat(80));

    try {
      console.log(`URL: ${test.config.url}`);
      console.log(`Headers:`, JSON.stringify(test.config.headers, null, 2));
      if (test.config.params) {
        console.log(`Params:`, JSON.stringify(test.config.params, null, 2));
      }
      console.log();

      const response = await axios(test.config);

      console.log(`✅ SUCCÈS - HTTP ${response.status}`);
      console.log();

      // Afficher les informations utiles
      if (response.data.count !== undefined) {
        console.log(`📊 Résultats: ${response.data.count} transports trouvés`);
      }

      if (response.data.results && Array.isArray(response.data.results)) {
        console.log(`📦 Transports retournés: ${response.data.results.length}`);

        if (response.data.results.length > 0) {
          const transport = response.data.results[0];
          console.log();
          console.log('📋 Premier transport:');
          console.log(`   UID: ${transport.uid}`);
          console.log(`   Status: ${transport.status}`);

          // Vérifier prix sous-traitant
          if (transport.charter?.price) {
            console.log(`   💰 Prix sous-traitant (charter.price): ${transport.charter.price}€`);
          } else if (transport.subcontracting?.price) {
            console.log(`   💰 Prix sous-traitant (subcontracting.price): ${transport.subcontracting.price}€`);
          } else if (transport.pricing?.invoicing_amount) {
            console.log(`   ⚠️ Prix client (pricing.invoicing_amount): ${transport.pricing.invoicing_amount}€`);
          }

          // Vérifier transporteur
          if (transport.charter?.carrier?.name) {
            console.log(`   🚛 Transporteur: ${transport.charter.carrier.name}`);
          } else if (transport.subcontracting?.carrier?.name) {
            console.log(`   🚛 Transporteur: ${transport.subcontracting.carrier.name}`);
          }

          // Vérifier route
          if (transport.origin?.address?.city && transport.destination?.address?.city) {
            console.log(`   📍 Route: ${transport.origin.address.city} → ${transport.destination.address.city}`);
          }
        }
      }

      successCount++;

    } catch (error) {
      console.log(`❌ ÉCHEC`);
      console.log();

      if (error.response) {
        console.log(`HTTP Status: ${error.response.status} ${error.response.statusText}`);
        console.log(`Response:`, JSON.stringify(error.response.data, null, 2));

        if (error.response.headers['www-authenticate']) {
          console.log(`WWW-Authenticate header: ${error.response.headers['www-authenticate']}`);
        }
      } else if (error.request) {
        console.log(`Pas de réponse du serveur`);
        console.log(`Error:`, error.message);
      } else {
        console.log(`Error:`, error.message);
      }
    }
  }

  console.log();
  console.log('='.repeat(80));
  console.log('  RÉSULTAT FINAL');
  console.log('='.repeat(80));
  console.log();

  if (successCount > 0) {
    console.log(`✅ ${successCount}/${tests.length} test(s) réussi(s)`);
    console.log();
    console.log('🎉 LA CLÉ API FONCTIONNE !');
    console.log();
    console.log('📝 PROCHAINES ÉTAPES:');
    console.log();
    console.log('1. Le format d\'authentification est confirmé: Authorization: Token <key>');
    console.log('2. L\'import Dashdoc va maintenant fonctionner');
    console.log('3. Vous pouvez lancer un import test:');
    console.log();
    console.log('   curl -X POST "http://rt-affret-ia-api-prod-v4.eba-quc9udpr.eu-central-1.elasticbeanstalk.com/api/v1/affretia/import/dashdoc" \\');
    console.log('     -H "Content-Type: application/json" \\');
    console.log('     -d \'{"organizationId":"test-org","months":6,"dryRun":true}\'');
    console.log();
  } else {
    console.log(`❌ 0/${tests.length} test(s) réussi(s)`);
    console.log();
    console.log('⚠️ LA CLÉ API NE FONCTIONNE TOUJOURS PAS');
    console.log();
    console.log('📝 ACTIONS À ENTREPRENDRE:');
    console.log();
    console.log('1. Vérifier auprès du support Dashdoc que la clé:');
    console.log('   8321c7a8f7fe8f75192fa15a6c883a11758e0084');
    console.log('   est bien ACTIVE et non RÉVOQUÉE/EXPIRÉE');
    console.log();
    console.log('2. Demander au support de vérifier:');
    console.log('   - Environnement: Production (api.dashdoc.com)');
    console.log('   - Permissions: Lecture transports + affretement');
    console.log('   - Restrictions IP: Aucune ou AWS eu-central-1');
    console.log();
    console.log('3. Ou régénérer une NOUVELLE clé API dans Dashdoc');
    console.log();
  }
}

// Exécution
runTests().catch(error => {
  console.error('Erreur fatale:', error);
  process.exit(1);
});

// Fix: appeler la bonne fonction
async function runTests() {
  await testDashdocAPI();
}
