# Test avec cURL pur (PowerShell version)
# Format EXACT fourni par le support Dashdoc

$API_KEY = "8321c7a8f7fe8f75192fa15a6c883a11758e0084"
$BASE_URL = "https://api.dashdoc.com/api/v4"

Write-Host "================================================================================" -ForegroundColor Cyan
Write-Host "  TEST DASHDOC API - cURL PUR (PowerShell)" -ForegroundColor Cyan
Write-Host "================================================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Clé API: $($API_KEY.Substring(0,20))..."
Write-Host "Format: Authorization: Token <key>"
Write-Host "Base URL: $BASE_URL"
Write-Host ""
Write-Host "================================================================================" -ForegroundColor Cyan
Write-Host ""

# Test 1: Simple (page_size=1)
Write-Host "TEST 1: GET /transports/?page_size=1" -ForegroundColor Yellow
Write-Host "--------------------------------------------------------------------------------"
Write-Host ""
Write-Host "Commande:"
Write-Host "curl -X GET ""${BASE_URL}/transports/?page_size=1"" \"
Write-Host "  -H ""Authorization: Token ${API_KEY}"" \"
Write-Host "  -H ""Accept: application/json"" \"
Write-Host "  -H ""Content-Type: application/json"" \"
Write-Host "  -v"
Write-Host ""
Write-Host "Résultat:" -ForegroundColor Cyan
Write-Host ""

$result1 = & curl -X GET "${BASE_URL}/transports/?page_size=1" `
  -H "Authorization: Token ${API_KEY}" `
  -H "Accept: application/json" `
  -H "Content-Type: application/json" `
  -v 2>&1

Write-Host $result1
Write-Host ""
Write-Host "================================================================================" -ForegroundColor Cyan
Write-Host ""

# Test 2: Avec filtres
Write-Host "TEST 2: GET /transports/?status=done&is_subcontracted=true&page_size=10" -ForegroundColor Yellow
Write-Host "--------------------------------------------------------------------------------"
Write-Host ""
Write-Host "Commande:"
Write-Host "curl -X GET ""${BASE_URL}/transports/?status=done&is_subcontracted=true&page_size=10"" \"
Write-Host "  -H ""Authorization: Token ${API_KEY}"" \"
Write-Host "  -H ""Accept: application/json"" \"
Write-Host "  -H ""Content-Type: application/json"" \"
Write-Host "  -v"
Write-Host ""
Write-Host "Résultat:" -ForegroundColor Cyan
Write-Host ""

$result2 = & curl -X GET "${BASE_URL}/transports/?status=done&is_subcontracted=true&page_size=10" `
  -H "Authorization: Token ${API_KEY}" `
  -H "Accept: application/json" `
  -H "Content-Type: application/json" `
  -v 2>&1

Write-Host $result2
Write-Host ""
Write-Host "================================================================================" -ForegroundColor Cyan
Write-Host ""

# Résumé
Write-Host "RÉSUMÉ DES TESTS" -ForegroundColor Yellow
Write-Host "================================================================================" -ForegroundColor Cyan
Write-Host ""

# Analyser les résultats
$success1 = $result1 -match "HTTP.*200" -or $result1 -match '"count"'
$success2 = $result2 -match "HTTP.*200" -or $result2 -match '"count"'

if ($success1) {
  Write-Host "✅ Test 1: Succès (HTTP 200)" -ForegroundColor Green
} else {
  Write-Host "❌ Test 1: Échec (HTTP non-200 ou erreur)" -ForegroundColor Red
}

if ($success2) {
  Write-Host "✅ Test 2: Succès (HTTP 200)" -ForegroundColor Green
} else {
  Write-Host "❌ Test 2: Échec (HTTP non-200 ou erreur)" -ForegroundColor Red
}

Write-Host ""
Write-Host "================================================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "NOTE: Vérifiez le HTTP Status Code dans la sortie verbose ci-dessus."
Write-Host ""
Write-Host "Si vous voyez 'HTTP/2 401' ou 'HTTP/1.1 401', l'authentification a échoué."
Write-Host "Si vous voyez 'HTTP/2 200' ou 'HTTP/1.1 200', l'authentification a réussi."
Write-Host ""

# Obtenir l'IP publique
Write-Host "================================================================================" -ForegroundColor Cyan
Write-Host "VOTRE IP PUBLIQUE (pour fournir au support Dashdoc)" -ForegroundColor Yellow
Write-Host "================================================================================" -ForegroundColor Cyan
Write-Host ""

try {
  $ipInfo = Invoke-RestMethod -Uri "https://api.ipify.org?format=json" -TimeoutSec 5
  Write-Host "IP publique: $($ipInfo.ip)" -ForegroundColor Green
  Write-Host ""
  Write-Host "Fournissez cette IP au support Dashdoc pour qu'ils vérifient"
  Write-Host "si la clé API a des restrictions IP."
} catch {
  Write-Host "⚠️ Impossible de récupérer l'IP publique" -ForegroundColor Yellow
}

Write-Host ""
