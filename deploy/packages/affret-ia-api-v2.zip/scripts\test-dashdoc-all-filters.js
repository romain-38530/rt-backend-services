/**
 * Test avec différents filtres pour voir combien de transports sont disponibles
 */

const axios = require('axios');

const API_KEY = '8321c7a8f7fe8f75192fa15a6c883a11758e0084';
const BASE_URL = 'https://api.dashdoc.eu/api/v4';

console.log('\n' + '='.repeat(80));
console.log('  TEST FILTRES DASHDOC - Compter les transports disponibles');
console.log('='.repeat(80));
console.log();

async function testFilters() {
  const tests = [
    // Test 1: TOUS les transports
    {
      name: 'TOUS les transports (sans filtre)',
      params: { page_size: 1 }
    },

    // Test 2: Transports terminés
    {
      name: 'Transports terminés (status=done)',
      params: { status: 'done', page_size: 1 }
    },

    // Test 3: Transports sous-traités
    {
      name: 'Transports sous-traités (is_subcontracted=true)',
      params: { is_subcontracted: true, page_size: 1 }
    },

    // Test 4: Transports terminés ET sous-traités
    {
      name: 'Transports terminés ET sous-traités',
      params: { status: 'done', is_subcontracted: true, page_size: 1 }
    },

    // Test 5: 6 derniers mois
    {
      name: '6 derniers mois (toutes statuts)',
      params: {
        created_after: new Date(Date.now() - 180 * 24 * 60 * 60 * 1000).toISOString(),
        page_size: 1
      }
    },

    // Test 6: 6 derniers mois + terminés
    {
      name: '6 derniers mois + terminés',
      params: {
        status: 'done',
        created_after: new Date(Date.now() - 180 * 24 * 60 * 60 * 1000).toISOString(),
        page_size: 1
      }
    },

    // Test 7: 6 derniers mois + sous-traités
    {
      name: '6 derniers mois + sous-traités',
      params: {
        is_subcontracted: true,
        created_after: new Date(Date.now() - 180 * 24 * 60 * 60 * 1000).toISOString(),
        page_size: 1
      }
    },

    // Test 8: 6 derniers mois + terminés + sous-traités (notre filtre actuel)
    {
      name: '6 derniers mois + terminés + sous-traités (FILTRE ACTUEL)',
      params: {
        status: 'done',
        is_subcontracted: true,
        created_after: new Date(Date.now() - 180 * 24 * 60 * 60 * 1000).toISOString(),
        page_size: 1
      }
    },

    // Test 9: 12 derniers mois
    {
      name: '12 derniers mois (tous)',
      params: {
        created_after: new Date(Date.now() - 365 * 24 * 60 * 60 * 1000).toISOString(),
        page_size: 1
      }
    },

    // Test 10: 12 derniers mois + terminés + sous-traités
    {
      name: '12 derniers mois + terminés + sous-traités',
      params: {
        status: 'done',
        is_subcontracted: true,
        created_after: new Date(Date.now() - 365 * 24 * 60 * 60 * 1000).toISOString(),
        page_size: 1
      }
    },

    // Test 11: 24 derniers mois
    {
      name: '24 derniers mois + terminés + sous-traités',
      params: {
        status: 'done',
        is_subcontracted: true,
        created_after: new Date(Date.now() - 730 * 24 * 60 * 60 * 1000).toISOString(),
        page_size: 1
      }
    },

    // Test 12: TOUS les transports terminés + sous-traités (sans filtre date)
    {
      name: 'TOUS terminés + sous-traités (SANS FILTRE DATE)',
      params: {
        status: 'done',
        is_subcontracted: true,
        page_size: 1
      }
    }
  ];

  console.log('Date du jour:', new Date().toISOString().split('T')[0]);
  console.log('6 mois = depuis:', new Date(Date.now() - 180 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]);
  console.log('12 mois = depuis:', new Date(Date.now() - 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]);
  console.log('24 mois = depuis:', new Date(Date.now() - 730 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]);
  console.log();

  const results = [];

  for (const test of tests) {
    console.log(`\n${'─'.repeat(80)}`);
    console.log(`TEST: ${test.name}`);
    console.log('─'.repeat(80));

    try {
      const response = await axios.get(`${BASE_URL}/transports/`, {
        headers: {
          'Authorization': `Token ${API_KEY}`,
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        params: test.params,
        timeout: 15000
      });

      const count = response.data.count;
      console.log(`✅ Résultat: ${count.toLocaleString('fr-FR')} transports`);

      results.push({
        name: test.name,
        count: count,
        success: true
      });

    } catch (error) {
      console.log(`❌ Erreur: ${error.message}`);
      results.push({
        name: test.name,
        count: 0,
        success: false
      });
    }
  }

  // Tableau récapitulatif
  console.log();
  console.log('='.repeat(80));
  console.log('  TABLEAU RÉCAPITULATIF');
  console.log('='.repeat(80));
  console.log();

  console.log('| Filtre | Transports disponibles |');
  console.log('|--------|------------------------|');
  results.forEach(r => {
    if (r.success) {
      console.log(`| ${r.name.padEnd(60)} | ${r.count.toLocaleString('fr-FR').padStart(20)} |`);
    }
  });

  console.log();
  console.log('='.repeat(80));
  console.log();

  // Recommandation
  const maxResult = results.reduce((max, r) => r.count > max.count ? r : max, { count: 0 });

  console.log('📊 ANALYSE:');
  console.log();
  console.log(`Filtre avec le PLUS de transports: ${maxResult.name}`);
  console.log(`Total: ${maxResult.count.toLocaleString('fr-FR')} transports`);
  console.log();

  const currentFilter = results.find(r => r.name.includes('FILTRE ACTUEL'));
  if (currentFilter) {
    console.log(`Filtre ACTUEL (6 mois + done + subcontracted): ${currentFilter.count.toLocaleString('fr-FR')} transports`);
    console.log();

    if (currentFilter.count < maxResult.count * 0.5) {
      console.log('⚠️ RECOMMANDATION: Votre filtre actuel récupère moins de 50% des transports disponibles.');
      console.log();
      console.log('Options pour récupérer plus de données:');
      console.log('1. Retirer le filtre status=done (inclure tous les statuts)');
      console.log('2. Augmenter la période (12 ou 24 mois au lieu de 6)');
      console.log('3. Retirer le filtre created_after (récupérer TOUS les transports historiques)');
    }
  }

  console.log();
}

testFilters().catch(error => {
  console.error('Erreur fatale:', error);
  process.exit(1);
});
