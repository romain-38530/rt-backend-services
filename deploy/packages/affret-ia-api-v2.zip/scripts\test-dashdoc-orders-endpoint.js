/**
 * Test de l'endpoint /orders/ plutôt que /transports/
 */

const axios = require('axios');

const API_KEY = '8321c7a8f7fe8f75192fa15a6c883a11758e0084';
const BASE_URL = 'https://api.dashdoc.eu/api/v4';

console.log('\n' + '='.repeat(80));
console.log('  TEST ENDPOINT /orders/ DASHDOC');
console.log('='.repeat(80));
console.log();

async function testOrdersEndpoint() {
  const endpoints = [
    // Endpoint 1: /orders/
    {
      name: '/orders/ (tous)',
      url: `${BASE_URL}/orders/`,
      params: { page_size: 1 }
    },

    // Endpoint 2: /orders/ non archivés
    {
      name: '/orders/ (non archivés)',
      url: `${BASE_URL}/orders/`,
      params: { archived: false, page_size: 1 }
    },

    // Endpoint 3: /orders/ terminés
    {
      name: '/orders/ (status=done)',
      url: `${BASE_URL}/orders/`,
      params: { status: 'done', page_size: 1 }
    },

    // Endpoint 4: /orders/ sous-traités
    {
      name: '/orders/ (is_subcontracted=true)',
      url: `${BASE_URL}/orders/`,
      params: { is_subcontracted: true, page_size: 1 }
    },

    // Endpoint 5: /orders/ terminés + sous-traités
    {
      name: '/orders/ (done + subcontracted)',
      url: `${BASE_URL}/orders/`,
      params: { status: 'done', is_subcontracted: true, page_size: 1 }
    },

    // Endpoint 6: /orders/ avec période
    {
      name: '/orders/ (6 derniers mois)',
      url: `${BASE_URL}/orders/`,
      params: {
        created_after: new Date(Date.now() - 180 * 24 * 60 * 60 * 1000).toISOString(),
        page_size: 1
      }
    }
  ];

  const results = [];

  for (const endpoint of endpoints) {
    console.log(`\n${'─'.repeat(80)}`);
    console.log(`TEST: ${endpoint.name}`);
    console.log('─'.repeat(80));
    console.log(`URL: ${endpoint.url}`);
    console.log(`Params: ${JSON.stringify(endpoint.params)}`);
    console.log();

    try {
      const response = await axios.get(endpoint.url, {
        headers: {
          'Authorization': `Token ${API_KEY}`,
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        params: endpoint.params,
        timeout: 15000
      });

      const count = response.data.count;
      console.log(`✅ SUCCÈS - ${count.toLocaleString('fr-FR')} résultats`);

      // Afficher le premier résultat
      if (response.data.results && response.data.results.length > 0) {
        const first = response.data.results[0];
        console.log('   Premier order:');
        console.log(`     UID: ${first.uid || first.id || 'N/A'}`);
        if (first.status) console.log(`     Status: ${first.status}`);
        if (first.shipper) console.log(`     Expéditeur: ${first.shipper.name || first.shipper}`);
        if (first.carrier) console.log(`     Transporteur: ${first.carrier.name || first.carrier}`);

        // Prix
        if (first.charter?.price) {
          console.log(`     💰 Prix charter: ${first.charter.price}€`);
        }
        if (first.subcontracting?.price) {
          console.log(`     💰 Prix subcontracting: ${first.subcontracting.price}€`);
        }
        if (first.pricing?.invoicing_amount) {
          console.log(`     💰 Prix facturation client: ${first.pricing.invoicing_amount}€`);
        }
      }

      results.push({
        name: endpoint.name,
        url: endpoint.url,
        params: endpoint.params,
        count: count,
        success: true
      });

    } catch (error) {
      if (error.response) {
        console.log(`❌ Erreur HTTP ${error.response.status}`);
        console.log(`Message: ${JSON.stringify(error.response.data)}`);
      } else {
        console.log(`❌ Erreur: ${error.message}`);
      }

      results.push({
        name: endpoint.name,
        url: endpoint.url,
        params: endpoint.params,
        count: 0,
        success: false,
        error: error.response ? error.response.status : error.message
      });
    }
  }

  // Tableau récapitulatif
  console.log();
  console.log('='.repeat(80));
  console.log('  TABLEAU RÉCAPITULATIF');
  console.log('='.repeat(80));
  console.log();

  console.log('| Endpoint | Résultats |');
  console.log('|----------|-----------|');
  results.forEach(r => {
    if (r.success) {
      const countStr = r.count.toLocaleString('fr-FR').padStart(10);
      console.log(`| ${r.name.padEnd(40)} | ${countStr} |`);
    } else {
      console.log(`| ${r.name.padEnd(40)} | ❌ ${String(r.error).padStart(10)} |`);
    }
  });

  console.log();
  console.log('='.repeat(80));
  console.log();

  // Comparer avec les résultats de /transports/
  console.log('📊 COMPARAISON:');
  console.log();
  console.log('/transports/?business_status=orders&archived=false: 8 371 affrètements');

  const ordersTotal = results.find(r => r.name === '/orders/ (tous)');
  if (ordersTotal && ordersTotal.success) {
    console.log(`/orders/ (tous): ${ordersTotal.count.toLocaleString('fr-FR')} orders`);

    if (ordersTotal.count === 8371) {
      console.log();
      console.log('✅ PARFAIT ! L\'endpoint /orders/ retourne exactement les 8371 affrètements !');
      console.log();
      console.log('Recommandation: Utiliser /orders/ plutôt que /transports/ avec business_status');
    } else if (Math.abs(ordersTotal.count - 8371) < 100) {
      console.log();
      console.log('✅ TRÈS PROCHE ! L\'endpoint /orders/ est le bon choix.');
    }
  }

  console.log();
}

testOrdersEndpoint().catch(error => {
  console.error('Erreur fatale:', error);
  process.exit(1);
});
