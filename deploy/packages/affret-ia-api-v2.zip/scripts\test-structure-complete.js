/**
 * Afficher la structure COMPLÈTE d'un transport
 */

const axios = require('axios');
const fs = require('fs');

const API_KEY = '8321c7a8f7fe8f75192fa15a6c883a11758e0084';
const BASE_URL = 'https://api.dashdoc.eu/api/v4';

console.log('\n' + '='.repeat(80));
console.log('  STRUCTURE COMPLÈTE D\'UN TRANSPORT DASHDOC');
console.log('='.repeat(80));
console.log();

async function inspectTransport() {
  try {
    // Récupérer UN transport en status=done
    const response = await axios.get(`${BASE_URL}/transports/`, {
      headers: {
        'Authorization': `Token ${API_KEY}`,
        'Content-Type': 'application/json'
      },
      params: {
        business_status: 'orders',
        archived: false,
        status: 'done',
        page_size: 1
      },
      timeout: 15000
    });

    if (response.data.results.length > 0) {
      const transport = response.data.results[0];

      console.log('Transport trouvé:');
      console.log(`  UID: ${transport.uid}`);
      console.log();

      // Sauvegarder la structure complète
      const filename = './transport-structure-complete.json';
      fs.writeFileSync(filename, JSON.stringify(transport, null, 2));

      console.log(`✅ Structure complète sauvegardée dans: ${filename}`);
      console.log();

      // Afficher les clés de premier niveau
      console.log('Clés de premier niveau disponibles:');
      Object.keys(transport).sort().forEach(key => {
        const value = transport[key];
        const type = Array.isArray(value) ? 'Array' : typeof value;
        const preview = type === 'object' && value !== null ?
          `{ ${Object.keys(value).join(', ')} }` :
          type === 'Array' ? `[${value.length} items]` :
          value;

        console.log(`  - ${key}: ${type} = ${preview}`);
      });

      console.log();
      console.log('─'.repeat(80));
      console.log();

      // Vérifier les champs importants
      console.log('Vérification des champs pour import:');
      console.log();

      console.log(`1. ROUTE:`);
      console.log(`   origin: ${transport.origin ? '✅' : '❌'}`);
      if (transport.origin) {
        console.log(`     address: ${transport.origin.address ? '✅' : '❌'}`);
        if (transport.origin.address) {
          console.log(`       city: ${transport.origin.address.city || 'N/A'}`);
          console.log(`       postcode: ${transport.origin.address.postcode || 'N/A'}`);
        }
      }

      console.log(`   destination: ${transport.destination ? '✅' : '❌'}`);
      if (transport.destination) {
        console.log(`     address: ${transport.destination.address ? '✅' : '❌'}`);
        if (transport.destination.address) {
          console.log(`       city: ${transport.destination.address.city || 'N/A'}`);
          console.log(`       postcode: ${transport.destination.address.postcode || 'N/A'}`);
        }
      }

      console.log();
      console.log(`2. PRIX SOUS-TRAITANT:`);
      console.log(`   charter: ${transport.charter ? '✅' : '❌'}`);
      if (transport.charter) {
        console.log(`     price: ${transport.charter.price || 'N/A'}`);
        console.log(`     purchase_price: ${transport.charter.purchase_price || 'N/A'}`);
        console.log(`     carrier: ${transport.charter.carrier ? '✅' : '❌'}`);
      }

      console.log(`   subcontracting: ${transport.subcontracting ? '✅' : '❌'}`);
      if (transport.subcontracting) {
        console.log(`     price: ${transport.subcontracting.price || 'N/A'}`);
        console.log(`     purchase_price: ${transport.subcontracting.purchase_price || 'N/A'}`);
        console.log(`     carrier: ${transport.subcontracting.carrier ? '✅' : '❌'}`);
      }

      console.log(`   pricing: ${transport.pricing ? '✅' : '❌'}`);
      if (transport.pricing) {
        console.log(`     invoicing_amount: ${transport.pricing.invoicing_amount || 'N/A'}`);
        console.log(`     carrier_price: ${transport.pricing.carrier_price || 'N/A'}`);
      }

      console.log();
      console.log(`3. CARRIER:`);
      console.log(`   carrier: ${transport.carrier ? '✅' : '❌'}`);
      if (transport.carrier) {
        console.log(`     name: ${transport.carrier.name || 'N/A'}`);
        console.log(`     pk: ${transport.carrier.pk || 'N/A'}`);
      }

      console.log();
      console.log(`4. CARGO:`);
      console.log(`   pallets_count: ${transport.pallets_count || 0}`);
      console.log(`   weight_kg: ${transport.weight_kg || 0}`);
      console.log(`   volume_m3: ${transport.volume_m3 || 0}`);

      console.log();

    } else {
      console.log('❌ Aucun transport trouvé');
    }

  } catch (error) {
    console.log('❌ Erreur:', error.message);
    if (error.response) {
      console.log(`HTTP ${error.response.status}:`, error.response.data);
    }
  }
}

inspectTransport().catch(error => {
  console.error('Erreur fatale:', error);
  process.exit(1);
});
