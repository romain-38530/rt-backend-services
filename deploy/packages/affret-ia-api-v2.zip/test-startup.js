// Test startup avec config EB
const mongoose = require('mongoose');

const config = {
  PORT: process.env.PORT || 8080,
  MONGODB_URI: process.env.MONGODB_URI || 'mongodb+srv://rt_admin:Symphonia2024!@stagingrt.v2jnoh2.mongodb.net/rt-affret-ia',
  NODE_ENV: process.env.NODE_ENV || 'production'
};

console.log('[TEST] Configuration:');
console.log(`  PORT: ${config.PORT}`);
console.log(`  MONGODB_URI: ${config.MONGODB_URI ? config.MONGODB_URI.replace(/:[^@]+@/, ':****@') : 'undefined'}`);
console.log(`  NODE_ENV: ${config.NODE_ENV}`);

console.log('\n[TEST] Testing MongoDB connection...');

mongoose.connect(config.MONGODB_URI, {
  serverSelectionTimeoutMS: 10000,
  socketTimeoutMS: 45000,
})
  .then(() => {
    console.log('[TEST] ✓ MongoDB connected successfully');
    console.log(`[TEST]   Database: ${mongoose.connection.db.databaseName}`);
    console.log(`[TEST]   Host: ${mongoose.connection.host}`);

    // Test listening on 0.0.0.0
    const express = require('express');
    const app = express();

    app.get('/', (req, res) => res.json({ status: 'ok', test: true }));
    app.get('/health', (req, res) => res.json({ status: 'healthy', mongodb: 'connected' }));

    const server = app.listen(config.PORT, '0.0.0.0', () => {
      console.log(`[TEST] ✓ Server listening on 0.0.0.0:${config.PORT}`);
      console.log('[TEST] Test endpoints:');
      console.log(`[TEST]   http://localhost:${config.PORT}/`);
      console.log(`[TEST]   http://localhost:${config.PORT}/health`);
      console.log('\n[TEST] Press Ctrl+C to exit');
    });

    server.on('error', (err) => {
      console.error('[TEST] ✗ Server error:', err.message);
      process.exit(1);
    });
  })
  .catch(err => {
    console.error('[TEST] ✗ MongoDB connection failed:', err.message);
    console.error('[TEST]   Error code:', err.code);
    console.error('[TEST]   Error name:', err.name);
    process.exit(1);
  });

// Timeout after 30 seconds
setTimeout(() => {
  console.log('\n[TEST] Timeout reached - test complete');
  process.exit(0);
}, 30000);
